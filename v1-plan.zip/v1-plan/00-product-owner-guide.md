# Product Owner Guide

**Parent:** [the_v1_plan.md](./the_v1_plan.md)
**Role:** Coherence authority for all v1.0 work
**Audience:** Any agent team working on any track, any time

---

## Purpose of This Document

This is the **product owner's brain in a file**. When an agent team finishes a sprint of work, or when a team is mid-task and unsure about a decision, they check in here. This document answers:

- Are we building the right thing?
- Are we building it the right way?
- Is this work going to integrate cleanly with everyone else's work?
- Did we actually finish, or did we leave a mess?

This is not a process document. It's a decision-making guide. It gives you the product's values, priorities, and quality bar so you can make autonomous decisions that stay aligned.

---

## Part 1: Product Identity

### What Provocations IS

Provocations is an **AI-augmented thinking workspace**. The user brings rough ideas. The AI challenges, questions, and provokes them into sharper, more complete thinking. The output is a polished document — but the real value is the thinking process that created it.

The canvas is the primary workspace. Users build **processing flows** by connecting nodes — research, interviews, text transformations, context documents, logic gates. The AI doesn't write for the user. It makes the user write better.

### What Provocations is NOT

- **Not a chatbot.** The AI is a collaborator with multiple expert perspectives, not a single assistant.
- **Not an AI writing tool.** We don't generate documents from a prompt. We help users develop their own ideas through structured provocation.
- **Not a diagramming tool.** The canvas looks like a flowchart but it's a **processing pipeline**. Nodes execute, produce output, and feed downstream.
- **Not a note-taking app.** Context documents support the thinking process — they aren't the product.

### The Core Promise

> "Would you rather have a tool that thinks for you, or a tool that makes you think?"

Every feature, every UI decision, every AI prompt should reinforce this promise. If a feature makes the user's thinking lazier, it's wrong. If it makes their thinking deeper, it's right.

### Who Uses This

**Primary users:** Knowledge workers who create documents as part of their job — product managers, strategists, researchers, consultants, founders, technical writers.

**What they have in common:** They need to produce high-quality written output and they know that the quality of the writing depends on the quality of the thinking behind it.

**What they struggle with:** Blank page paralysis, blind spots in their reasoning, lack of expert feedback, difficulty structuring complex ideas, time pressure.

---

## Part 2: Product Values (Decision Tiebreakers)

When two approaches both seem reasonable, use these values to break the tie. They're in priority order.

### 1. Reliability over features

A feature that works 100% of the time beats two features that work 90% of the time. For v1.0, we are explicitly choosing to harden existing features over adding new ones. If you're tempted to add something new, ask: "Does something existing need to work better first?"

### 2. User thinking over AI output

Features that help the user think (provocations, challenges, structured interviews) are more valuable than features that generate output for them. When designing AI interactions, bias toward asking the user a hard question over giving them a polished answer.

### 3. Simplicity over power

If a feature requires explanation, it's too complex. The canvas should feel intuitive after 5 minutes. Individual nodes should be self-explanatory. If you're adding configuration options, ask: "Can the system just make the right choice?"

### 4. Transparency over magic

Users should always know what the AI is doing, what context it's using, and what it will cost. The LLM hover preview (showing tokens, cost, context blocks) is a core differentiator. Never make an LLM call without the user understanding what's happening.

### 5. Integration over isolation

Every feature must work within the canvas ecosystem. A node that doesn't connect to other nodes, doesn't participate in chains, or doesn't save/load properly is incomplete. No islands.

### 6. Speed over perfection

The app should feel instant. Page loads, saves, AI responses — every interaction should feel fast. Users will tolerate imperfect AI output before they'll tolerate waiting. Optimize for perceived speed (streaming, optimistic UI) even when actual speed is constrained.

---

## Part 3: Quality Bar

### What "Done" Means

A task is done when ALL of the following are true:

#### Functional Completeness
- [ ] The feature works as described in the plan document
- [ ] It works with all relevant node types (not just the one you tested with)
- [ ] It works when the canvas has 1 node and when it has 50 nodes
- [ ] It works when the user has no documents and when they have 100 documents
- [ ] It works on first use and on the 100th use
- [ ] It handles empty states (no input, no selection, no context)
- [ ] It handles error states (network failure, LLM timeout, invalid input)

#### Code Quality
- [ ] `npm run check` passes with zero errors (including pre-existing ones — fix them)
- [ ] No `any` types in new code
- [ ] No `console.log` debugging statements left in
- [ ] No commented-out code
- [ ] No TODOs, FIXMEs, or HACKs left unresolved
- [ ] No placeholder text ("Lorem ipsum", "TODO: implement", "coming soon")

#### Integration
- [ ] Save/load works — the feature survives a canvas save and reload
- [ ] Blueprint works — the feature survives blueprint save and apply
- [ ] Auto-save works — the feature doesn't break the 2-second debounced auto-save
- [ ] Undo/redo works — the feature can be undone and redone
- [ ] Other node types aren't broken — check at least 3 other node types still work

#### Consistency
- [ ] Uses ProvokeText for all text display (ADR requirement)
- [ ] LLM-triggering buttons wrapped with LlmHoverButton (ADR requirement)
- [ ] Follows the design system (amber primary, aged paper aesthetic, correct fonts)
- [ ] Loading states use consistent patterns (spinner, skeleton, or pulse)
- [ ] Error states use consistent patterns (toast for transient, inline for persistent)
- [ ] Keyboard accessible (at minimum: focusable, dismissable with ESC)

#### Documentation
- [ ] Version bumped in `version.ts` with release note entry
- [ ] Component registry updated if new/modified components
- [ ] CLAUDE.md updated if architectural patterns changed
- [ ] Plan document updated (task marked DONE)

### What "Done" Does NOT Mean

- "It works on my machine" — Does it work after a fresh page load? After clearing cache?
- "The happy path works" — What about errors, edge cases, empty states?
- "I'll clean it up later" — No. Clean it up now. Later doesn't exist.
- "It's feature-complete but has some rough edges" — Rough edges ARE the work for v1.0.

---

## Part 4: Sprint Review Protocol

### When to Run a Review

Run a product owner review:
1. **After every completed task** (quick self-check, 2 minutes)
2. **After every completed track milestone** (full review, 15 minutes)
3. **When unsure about a design decision** (alignment check)
4. **Before merging work from parallel agents** (integration check)

### Self-Check (2 Minutes)

Every agent should ask themselves these questions before declaring a task done:

```
COMPLETENESS
  Did I build exactly what the plan document described?
  Did I leave any TODOs, placeholders, or "future work" notes?
  Did I handle error cases, not just the happy path?

QUALITY
  Does npm run check pass?
  Did I introduce any new TypeScript errors?
  Is my code consistent with the patterns in the surrounding codebase?

INTEGRATION
  Does save/load still work?
  Do other node types still work?
  Did I break any existing functionality?

ALIGNMENT
  Does this feature reinforce the product promise ("makes you think")?
  Would a new user understand this without documentation?
  Did I add complexity that could have been avoided?
```

### Full Sprint Review (15 Minutes)

For milestone completions or when multiple agents' work needs to merge:

#### Step 1: Inventory Check
```
List every file changed.
For each file:
  - What was the intent of the change?
  - Is the change complete or partial?
  - Are there any temporary workarounds?
  - Does the file still pass npm run check?
```

#### Step 2: Integration Smoke Test
```
1. Fresh page load — does the app render without errors?
2. Create a new canvas — add one of each node type involved in the sprint
3. Connect nodes — do edges render correctly?
4. Run a chain — does execution complete?
5. Save and reload — does everything survive?
6. Load a blueprint — does it apply cleanly?
7. Open Context Store — does it work?
```

#### Step 3: Coherence Check
```
Does this sprint's work:
  - Move us toward v1.0, not sideways?
  - Harden existing features (preferred) or add new ones (justify)?
  - Integrate with other tracks' work without conflict?
  - Maintain the product's core identity and values?
  - Leave the codebase in better shape than we found it?
```

#### Step 4: Debt Inventory
```
After this sprint:
  - What new technical debt was introduced? (Be honest)
  - What pre-existing debt was discovered?
  - What debt was paid down?
  - Net: are we in more or less debt than before?
```

---

## Part 5: Decision Framework

### Feature Decisions

When evaluating whether to build something:

```
                  ┌─────────────────────┐
                  │ Does it make users   │
                  │ think deeper/better? │
                  └──────┬──────────────┘
                         │
                    Yes  │  No
                    ┌────┴────┐
                    │         │
              ┌─────▼──┐  ┌──▼──────────────┐
              │ Does it │  │ Does it support  │
              │ exist   │  │ reliability,     │
              │ already?│  │ security, or     │
              │         │  │ monetization?    │
              └──┬──────┘  └──┬──────────────┘
                 │            │
            Yes  │  No   Yes  │  No
            ┌────┴┐  ┌───┘    │
            │     │  │        │
         ┌──▼──┐ ┌▼──▼─┐  ┌──▼───┐
         │HARDEN│ │BUILD │  │DEFER │
         │ IT   │ │ IT   │  │ IT   │
         └──────┘ └──────┘  └──────┘
```

### Architecture Decisions

When choosing between approaches:

1. **Prefer the approach that changes fewer files.** Less blast radius = less integration risk.
2. **Prefer the approach that follows existing patterns.** Consistency beats cleverness.
3. **Prefer the approach that's testable.** If you can't test it, you can't trust it.
4. **Prefer the approach that fails gracefully.** If it breaks, does the user lose work? (Must be no.)
5. **Prefer the approach that doesn't require coordination.** If it needs other teams to adjust, it's more expensive than it looks.

### Scope Decisions

When a task turns out to be bigger than expected:

```
Original estimate: 2 hours
Actual so far: 4 hours and I'm 60% done

Options:
  A. Push through (if the remaining 40% is well-understood)
  B. Ship what's working + document what's left (if the 60% is independently valuable)
  C. Stop and re-scope (if the approach is wrong, not just slow)

NEVER: Ship something broken. If 60% is incomplete without the other 40%, don't ship.
```

---

## Part 6: Cross-Track Coordination

### Dependency Map

```
Track 1 (Stability)     → Foundation for everything. Do first.
Track 2 (Performance)   → Depends on Track 1 (tests catch regressions)
Track 3 (Security)      → Independent. Can parallel with Track 1.
Track 4 (UX Polish)     → Depends on Track 2 (perf fixes before polish)
Track 5 (Features)      → Depends on Track 1 (tests before feature work)
Track 6 (Monetization)  → Depends on Track 3 (security before payments)
Track 7 (Infrastructure)→ Depends on Track 1 (tests before CI)
Track 8 (Documentation) → Can start anytime (low dependency)
Track 9 (AI)            → Independent. Can parallel with anything.
Track 10 (Collaboration)→ Depends on Track 3 (security) + Track 6 (team tier)
```

### Parallel Work Rules

When multiple agents work simultaneously:

1. **Claim before starting.** Mark tasks `[IN PROGRESS]` in the plan doc. Check for conflicts.
2. **Stay in your lane.** Each track has clear file boundaries. If you need to edit a file another track owns, coordinate first.
3. **Don't refactor shared code.** If you need to change `FlowWorkspace.tsx`, `routes.ts`, `schema.ts`, or `useFlowCanvas.ts`, check if other agents are also touching those files.
4. **Integration test before merge.** When two agents' branches come together, run the full smoke test from Section 4.

### File Ownership by Track

| File / Directory | Primary Track | Touch With Caution |
|-----------------|---------------|-------------------|
| `tests/` | Track 1 | — |
| `client/src/components/flow/` | Track 2, 5 | Track 1, 4, 10 |
| `client/src/pages/FlowWorkspace.tsx` | Track 1 (decomp) | Everyone |
| `server/routes.ts` | Track 3, 5, 6 | Track 7 |
| `server/llm.ts`, `llm-gateway.ts` | Track 9 | Track 3, 6 |
| `shared/schema.ts` | Track 5, 6 | Track 3, 10 |
| `server/crypto.ts` | Track 3 | Track 1 |
| `client/src/lib/version.ts` | Everyone (bumps) | — |
| `CLAUDE.md` | Whoever changes patterns | — |

---

## Part 7: Anti-Patterns

Things that have gone wrong before and MUST NOT happen again:

### 1. The 7800-Line File
FlowWorkspace.tsx grew to 7800 lines because features were added without extraction. **New code must not make large files larger.** If a file is over 500 lines, extract before adding.

### 2. The Dual Schema Drift
`ensureTables()` and Drizzle schema have drifted before, causing recurring deploy issues. **Every schema change must update both.** This is documented in CLAUDE.md and it's non-negotiable.

### 3. The Cache Poisoning
In v0.14.2-14.3, one component's React Query `queryFn` normalized data differently, poisoning the shared cache for all other components. **Never change the shape of cached data without checking all consumers.**

### 4. The Silent Failure
Features that silently fail (no error, no feedback, just... nothing happens) are worse than crashes. **Every user action must produce visible feedback** — success, loading, or error.

### 5. The "Works in Isolation" Feature
A feature that works perfectly when tested alone but breaks when combined with other features. **Always test with other nodes on the canvas, with saved canvases, with chain execution active.**

### 6. The Scope Creep Fix
A bug fix that turns into a refactor that turns into a new feature. **Fix the bug. Ship the fix. If the refactor is needed, that's a separate task.**

### 7. The Phantom TODO
Code committed with `// TODO: handle error case` or `// FIXME: this is a hack`. **These are bugs, not todos.** Handle the error case. Remove the hack. If you can't right now, file it as a tracked task in the plan docs, not a comment in code.

---

## Part 8: The v1.0 Readiness Checklist

Before we can call it v1.0, ALL of these must be true:

### Non-Negotiable
- [ ] Zero known crash-causing bugs
- [ ] All 17 node types: compact, expanded, save/load, chain execution work
- [ ] Canvas save/load is 100% reliable (no data loss, no corruption)
- [ ] Encryption is audited and confirmed secure
- [ ] Authentication covers every endpoint
- [ ] Rate limiting is in place
- [ ] Stripe payments work end-to-end
- [ ] `npm run check` and `npm run build` pass with zero errors
- [ ] Test suite exists with >60% coverage on critical paths
- [ ] A new user can sign up and understand the product in 5 minutes

### Important
- [ ] Performance: 50-node canvas pans smoothly
- [ ] Mobile: at minimum, read-only canvas viewing works
- [ ] Help: keyboard shortcut overlay and contextual help buttons exist
- [ ] Accessibility: WCAG 2.1 AA for core flows
- [ ] CI pipeline runs on every PR
- [ ] Database backups are automated
- [ ] Error monitoring captures and surfaces issues

### Nice-to-Have for v1.0
- [ ] Real-time collaboration (can ship as v1.1)
- [ ] Team workspaces (can ship as v1.1)
- [ ] Custom personas (can ship as v1.1)
- [ ] Smart AI suggestions (can ship as v1.2)

---

## Part 9: Using This Guide as an Agent

If you are an AI agent working on a track, here's your protocol:

### Before Starting Work
1. Read this guide (you're doing that now)
2. Read your track's plan document
3. Check for `[IN PROGRESS]` markers — don't duplicate work
4. Mark your task `[IN PROGRESS]`

### During Work
5. Follow the quality bar in Part 3 — every checkbox matters
6. When making a design decision, check Part 2 (values) and Part 5 (decision framework)
7. If you're touching shared files, check the ownership table in Part 6
8. If scope grows beyond the original task, stop and re-scope (Part 5)

### After Work
9. Run the self-check from Part 4
10. Run `npm run check` — it must pass
11. Mark your task `[DONE]` in the plan document
12. Bump version in `version.ts` with release note
13. If you discovered new issues, add them as tasks to the relevant plan document

### When Unsure
14. Check this guide first — the answer is probably here
15. If the answer isn't here, ask: "Does this reinforce or undermine the product promise?"
16. If still unsure, flag it for the human product owner — don't guess on important decisions

---

## Part 10: Evolving This Guide

This guide is version-controlled and should be updated when:

- A new anti-pattern is discovered (add to Part 7)
- A quality gate is found to be insufficient (tighten Part 3)
- Cross-track coordination rules need updating (Part 6)
- The v1.0 readiness checklist changes (Part 8)

Every update should include a date and brief note about what changed and why.

**Last updated:** 2026-03-07 — Initial version
