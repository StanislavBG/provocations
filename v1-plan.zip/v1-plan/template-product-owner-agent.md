# How to Set Up a Product Owner Agent

**What this is:** A template and methodology for creating a "product owner brain in a file" — a reference document that any AI agent team can consult to stay aligned with product goals, maintain quality, and integrate cleanly with other teams' work.

**Who this is for:** Anyone managing a software project with AI agent teams (Claude Code, Cursor, Copilot Workspace, or similar) who wants coherent, high-quality output without micromanaging every decision.

---

## Why You Need This

AI agents are powerful but directionless. They'll build exactly what you ask for — but they'll also:
- Drift from the product's identity when making judgment calls
- Leave TODOs, placeholders, and "future work" comments
- Build features that work in isolation but break when integrated
- Over-engineer some things and under-engineer others
- Lose sight of the user when deep in implementation

A Product Owner Agent document solves this by giving every agent the same decision-making context, quality bar, and self-review protocol. It's the equivalent of having a product owner sitting next to every developer — except it scales.

---

## The Document Structure

A Product Owner Agent guide has **10 sections**. Each one serves a specific purpose. Skip none of them — they work together.

### Section 1: Product Identity

**Purpose:** Prevent identity drift. Agents make hundreds of micro-decisions. Without a clear product identity, those decisions average out to generic software.

**What to include:**
- What the product IS (2-3 sentences, specific)
- What the product is NOT (3-4 explicit anti-definitions)
- The core promise (one sentence a user would repeat to a friend)
- Who uses it and why (primary persona, their pain, their goal)

**How to write it:**
```markdown
## Product Identity

### What [Product] IS
[Product] is a [specific category] that helps [specific users] do [specific thing]
by [specific mechanism that differentiates you].

### What [Product] is NOT
- Not a [closest competitor category]. We differ because [key difference].
- Not a [common misconception]. That implies [wrong assumption].
- Not a [adjacent category]. We focus on [narrower scope] specifically.

### The Core Promise
> "[One sentence. The thing users would say to explain why they use this.]"

### Who Uses This
**Primary users:** [Role] who [activity].
**What they struggle with:** [2-3 specific pain points your product addresses].
```

**Test:** Read your product identity section and then imagine an agent deciding whether to add a feature. Does the identity make the right answer obvious? If not, sharpen it.

---

### Section 2: Product Values (Ranked)

**Purpose:** Break ties. When two approaches both seem fine, agents need a tiebreaker. Unranked values are useless — ranking them is the hard, important work.

**What to include:**
- 5-7 values, in strict priority order
- Each value framed as "[X] over [Y]" — not "[X] is good"
- A one-sentence explanation of what this means in practice

**How to write it:**

```markdown
## Product Values

When two approaches both seem reasonable, use these to break the tie.
In priority order:

### 1. [Value A] over [Value B]
[One sentence explaining what this means in practice for this product.]

### 2. [Value C] over [Value D]
[One sentence.]

### 3. ...
```

**Common value pairs to consider:**
- Reliability over features
- Simplicity over power
- Speed over completeness
- User control over automation
- Transparency over magic
- Convention over configuration
- Integration over isolation
- Shipping over perfection
- Security over convenience
- Accessibility over aesthetics

**Test:** Take your top 3 values and think of a real decision where they'd conflict with each other. Does the ranking produce the right answer? If values 2 and 3 would override value 1 in practice, your ranking is wrong.

---

### Section 3: Quality Bar

**Purpose:** Define "done" objectively. Agents will declare victory at the first sign of working code unless you define what working actually means.

**What to include:**
- A checklist organized by category (functional, code quality, integration, consistency, documentation)
- Explicit "done does NOT mean" section (common false finishes)
- Project-specific requirements (your testing framework, your style guide, your ADRs)

**How to write it:**

```markdown
## Quality Bar

### What "Done" Means

A task is done when ALL of the following are true:

#### Functional Completeness
- [ ] The feature works as described in the spec
- [ ] It handles empty states (no data, no selection, no input)
- [ ] It handles error states (network failure, bad input, timeout)
- [ ] It works at scale (not just with 1 item — test with N items)

#### Code Quality
- [ ] Type checking passes with zero errors
- [ ] No debugging artifacts left in (console.log, commented code, TODOs)
- [ ] Follows existing patterns in the codebase (don't invent new patterns)
- [ ] No security vulnerabilities introduced (injection, XSS, IDOR, etc.)

#### Integration
- [ ] Existing features still work (test at least 3 adjacent features)
- [ ] Data persistence works (save, reload, verify)
- [ ] State management is consistent (no stale cache, no race conditions)

#### Documentation
- [ ] Version bumped (if your project tracks versions)
- [ ] Relevant docs updated (README, architecture docs, API docs)
- [ ] Plan document updated (task marked done)

### What "Done" Does NOT Mean
- "The happy path works" — Edge cases ARE the work.
- "It works in isolation" — Integration IS the work.
- "I'll clean it up later" — Later doesn't exist.
- "It compiles" — Compiling is the beginning, not the end.
```

**Customize for your project:** Add your specific linting rules, test coverage targets, accessibility requirements, performance budgets, and any ADRs (Architecture Decision Records) that agents must follow.

---

### Section 4: Sprint Review Protocol

**Purpose:** Catch problems before they compound. A 2-minute self-check after every task prevents the kind of drift that turns into a 2-day cleanup.

**What to include:**
- A quick self-check (agents run after every task, ~2 minutes)
- A full review (run at milestones or before merging parallel work, ~15 minutes)
- A concrete smoke test sequence specific to your product

**How to write it:**

```markdown
## Sprint Review Protocol

### Self-Check (After Every Task)

COMPLETENESS
  Did I build exactly what the spec described?
  Did I leave any TODOs, placeholders, or "future work" notes?
  Did I handle error cases, not just the happy path?

QUALITY
  Does the build pass? Does lint pass? Do tests pass?
  Did I introduce any new warnings or errors?
  Is my code consistent with patterns in surrounding code?

INTEGRATION
  Do adjacent features still work?
  Does data persistence survive a round-trip (save → load)?
  Did I break any existing functionality?

ALIGNMENT
  Does this reinforce or undermine the product promise?
  Would a new user understand this without explanation?
  Did I add complexity that could have been avoided?

### Full Review (At Milestones)

#### Step 1: Inventory
List every file changed. For each: what changed, is it complete, any workarounds?

#### Step 2: Smoke Test
[Write a numbered sequence of 5-10 manual tests specific to your product.
Cover: fresh load, core workflow, data persistence, error recovery.]

#### Step 3: Coherence Check
Does this sprint's work move toward the goal or sideways?
Does it integrate with other teams' work without conflict?
Does it maintain the product's identity and values?

#### Step 4: Debt Inventory
New debt introduced? Pre-existing debt discovered? Debt paid down?
Net: are we in more or less debt than before?
```

---

### Section 5: Decision Framework

**Purpose:** Help agents make design decisions autonomously without defaulting to "ask the human." Most decisions follow patterns — codify those patterns.

**What to include:**
- A feature decision flowchart (build it, harden it, or defer it)
- Architecture decision heuristics (which approach to prefer)
- Scope management guidance (what to do when a task grows)

**How to write it:**

```markdown
## Decision Framework

### Feature Decisions

Should I build this?
  1. Does it serve the core promise? → No → DEFER
  2. Does it already exist? → Yes → HARDEN it instead
  3. Is it in the current milestone? → No → DEFER
  4. Can I finish it completely (not partially)? → No → SCOPE DOWN or DEFER
  5. → BUILD it

### Architecture Decisions

When choosing between approaches:
  1. Prefer fewer changed files (less blast radius)
  2. Prefer existing patterns (consistency > cleverness)
  3. Prefer testable approaches (if you can't test it, you can't trust it)
  4. Prefer graceful failure (user must never lose work)
  5. Prefer independence (avoid requiring other teams to adjust)

### Scope Decisions

When a task grows beyond the original estimate:
  A. Push through — if the remaining work is well-understood
  B. Ship the working subset — if it's independently valuable
  C. Stop and re-scope — if the approach is wrong, not just slow
  NEVER: Ship something broken or incomplete without flagging it
```

---

### Section 6: Cross-Team Coordination

**Purpose:** Prevent merge conflicts, broken integrations, and duplicated work when multiple agents work in parallel.

**What to include:**
- A dependency map between workstreams
- File/module ownership table
- Rules for working on shared code

**How to write it:**

```markdown
## Cross-Team Coordination

### Dependency Map
[List your workstreams and their dependencies. Which must go first?
Which can run in parallel? Draw the DAG.]

### File Ownership

| File / Directory | Primary Owner | Touch With Caution |
|-----------------|---------------|-------------------|
| [core-module/] | [Team A] | [Team B, C] |
| [shared-types] | [Team B] | [Everyone] |
| [config files] | [Team D] | [Everyone] |

### Parallel Work Rules
1. Claim before starting — mark tasks in progress, check for conflicts
2. Stay in your lane — edit files your track owns, coordinate for shared files
3. Don't refactor shared code — if you need to change shared modules, flag it
4. Integration test before merge — run the smoke test when branches combine
```

---

### Section 7: Anti-Patterns

**Purpose:** Institutional memory. Document specific things that have gone wrong so they don't repeat. This section grows over time — it's the most valuable part of the guide long-term.

**What to include:**
- 5-10 specific anti-patterns drawn from real project history
- Each with: what happened, why it was bad, what to do instead

**How to write it:**

```markdown
## Anti-Patterns

### 1. [Name]
**What happened:** [Specific incident]
**Why it was bad:** [Concrete consequence]
**Rule:** [What to do instead]

### 2. [Name]
...
```

**Starter anti-patterns (common across projects):**
- **The Growing File:** One file absorbs all new code until it's unmaintainable. Rule: extract before adding if file > N lines.
- **The Silent Failure:** Feature fails without any user feedback. Rule: every action must produce visible feedback.
- **The Phantom TODO:** Code ships with TODO/FIXME comments. Rule: handle it now or file it as a tracked task.
- **The Works-in-Isolation Feature:** Tested alone, breaks when combined. Rule: always test in context.
- **The Scope Creep Fix:** Bug fix becomes refactor becomes new feature. Rule: fix the bug, ship the fix, scope the rest separately.
- **The Cache Surprise:** Changing data shape in one place breaks consumers elsewhere. Rule: check all consumers before changing shared data.

---

### Section 8: Release Readiness Checklist

**Purpose:** Define the finish line. Without this, "done" is a feeling, not a fact.

**What to include:**
- Non-negotiable items (must be true or we don't ship)
- Important items (should be true, exceptions need justification)
- Nice-to-have items (can ship without, track for next release)

**How to write it:**

```markdown
## Release Readiness Checklist

### Non-Negotiable
- [ ] [Critical quality gates — zero crashes, data integrity, security]
- [ ] [Core workflows work end-to-end]
- [ ] [Build and deployment pipeline works]

### Important
- [ ] [Performance targets met]
- [ ] [Accessibility baseline met]
- [ ] [Documentation exists for core features]

### Nice-to-Have
- [ ] [Features that can ship in a follow-up release]
```

---

### Section 9: Agent Protocol

**Purpose:** Step-by-step operating procedure for an AI agent. Removes ambiguity about when to check the guide and what to do at each phase.

**How to write it:**

```markdown
## Agent Protocol

### Before Starting Work
1. Read this guide
2. Read your task's spec document
3. Check for in-progress markers — don't duplicate work
4. Mark your task in-progress

### During Work
5. Follow the quality bar — every checkbox
6. Check values and decision framework for design decisions
7. Check file ownership before editing shared code
8. If scope grows, stop and re-scope

### After Work
9. Run the self-check
10. Run the build / type check / tests — must pass
11. Mark task done, bump version, update docs

### When Unsure
12. Check this guide — the answer is usually here
13. Ask: "Does this reinforce or undermine the product promise?"
14. If still unsure, flag for the human — don't guess on important decisions
```

---

### Section 10: Evolution

**Purpose:** Keep the guide alive. A stale guide is worse than no guide — agents will follow outdated rules.

```markdown
## Evolution

Update this guide when:
- A new anti-pattern is discovered (add to Section 7)
- A quality gate proves insufficient (tighten Section 3)
- Coordination rules need updating (Section 6)
- The release checklist changes (Section 8)

Every update: date + brief note on what changed and why.
```

---

## How to Deploy This

### Step 1: Write Your Guide (2-4 hours)

Use the 10-section structure above. Don't skip sections — each one plugs a specific failure mode. The hardest parts will be:
- **Ranking your values** (Section 2) — this requires actual decisions
- **Writing anti-patterns** (Section 7) — this requires honesty about past failures
- **Defining the quality bar** (Section 3) — this requires specificity

### Step 2: Place It in Your Project

Put it where agents will find it:
- In your project's plan/docs directory
- Referenced from your main planning document
- Mentioned in your CLAUDE.md / AGENTS.md / system prompt

### Step 3: Reference It in Agent Instructions

When spinning up agent teams, include in their prompt:
```
Before starting work, read [path/to/product-owner-guide.md].
After completing each task, run the self-check from Section 4.
When making design decisions, consult Sections 2 and 5.
```

### Step 4: Run Sprint Reviews

After each milestone:
1. Run the full review protocol (Section 4)
2. Update anti-patterns with anything that went wrong (Section 7)
3. Tighten the quality bar if things slipped through (Section 3)

### Step 5: Evolve It

The guide should get better with every sprint. The anti-patterns section especially — it's your project's institutional memory. After 3-4 sprints, you'll have a guide that's deeply specific to your project and catches most problems before they happen.

---

## Checklist: Is Your Guide Ready?

- [ ] Section 1 (Identity): Could an agent correctly reject a feature that doesn't fit?
- [ ] Section 2 (Values): Are values ranked, not just listed? Do rankings reflect real tradeoffs?
- [ ] Section 3 (Quality Bar): Is "done" defined with checkboxes, not vibes?
- [ ] Section 4 (Reviews): Is there a concrete smoke test sequence for your product?
- [ ] Section 5 (Decisions): Can an agent resolve a scope question without asking you?
- [ ] Section 6 (Coordination): Do agents know which files they can and can't touch?
- [ ] Section 7 (Anti-Patterns): Are there at least 5 patterns from real project history?
- [ ] Section 8 (Readiness): Is the release gate defined with non-negotiables?
- [ ] Section 9 (Protocol): Is the before/during/after workflow unambiguous?
- [ ] Section 10 (Evolution): Is there a process for keeping the guide current?

If all boxes are checked, your Product Owner Agent is ready to ride along.
