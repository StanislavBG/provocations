# Track 10: Collaboration & Social

**Parent:** [the_v1_plan.md](./the_v1_plan.md)
**Priority:** Medium
**Milestone:** M4 (v0.30–v0.39)

---

## 10.1 Real-Time Canvas Collaboration

**Current state:** Canvas broadcast exists (500ms debounced full-sync, added v0.13.0). It's a basic "last-write-wins" approach — no conflict resolution, no cursors, no presence.

### 10.1.1 Architecture Options

#### Option A: WebSocket Server (Recommended)

```typescript
// server/collaboration.ts
import { WebSocketServer } from "ws";

interface CollabMessage {
  type: "cursor" | "node-update" | "node-create" | "node-delete" | "edge-update" | "presence";
  canvasId: string;
  userId: string;
  payload: any;
  timestamp: number;
  version: number; // Optimistic concurrency
}

const wss = new WebSocketServer({ noServer: true });
const rooms = new Map<string, Set<WebSocket>>(); // canvasId → connected clients

wss.on("connection", (ws, req) => {
  const canvasId = extractCanvasId(req);
  const userId = extractUserId(req);

  // Join room
  if (!rooms.has(canvasId)) rooms.set(canvasId, new Set());
  rooms.get(canvasId).add(ws);

  // Broadcast presence
  broadcast(canvasId, {
    type: "presence",
    userId,
    payload: { status: "joined", cursor: null },
  }, ws);

  ws.on("message", (data) => {
    const msg = JSON.parse(data);
    // Validate + broadcast to other room members
    broadcast(canvasId, msg, ws);
  });

  ws.on("close", () => {
    rooms.get(canvasId)?.delete(ws);
    broadcast(canvasId, {
      type: "presence",
      userId,
      payload: { status: "left" },
    });
  });
});

function broadcast(canvasId: string, message: CollabMessage, exclude?: WebSocket) {
  const room = rooms.get(canvasId);
  if (!room) return;
  const data = JSON.stringify(message);
  for (const client of room) {
    if (client !== exclude && client.readyState === WebSocket.OPEN) {
      client.send(data);
    }
  }
}
```

#### Option B: CRDT-Based (Future)

For true conflict-free editing, use a CRDT library like Yjs:
```typescript
// More complex but handles concurrent edits properly
// Especially important for document text co-editing
// Evaluate: yjs + y-websocket
```

**Recommendation:** Start with Option A (WebSocket broadcast) for node-level operations. CRDTs only if we need character-level document co-editing.

### 10.1.2 Presence UI

```typescript
// Show collaborator avatars + cursors on canvas

interface CollaboratorPresence {
  userId: string;
  displayName: string;
  avatar: string;
  cursorPosition: { x: number; y: number } | null;
  selectedNodeId: string | null;
  color: string; // Assigned per-session
}

// Render as floating avatars in top-right corner
function CollaboratorBar({ collaborators }) {
  return (
    <div className="absolute top-2 right-2 flex -space-x-2">
      {collaborators.map(c => (
        <Avatar key={c.userId} style={{ borderColor: c.color }}>
          <AvatarImage src={c.avatar} />
          <AvatarFallback>{c.displayName[0]}</AvatarFallback>
        </Avatar>
      ))}
    </div>
  );
}

// Render cursor on canvas
function CollaboratorCursor({ position, color, name }) {
  return (
    <div
      className="absolute pointer-events-none z-50"
      style={{ left: position.x, top: position.y }}
    >
      <MousePointer2 className="w-4 h-4" style={{ color }} />
      <span className="text-xs px-1 rounded" style={{ background: color }}>
        {name}
      </span>
    </div>
  );
}
```

### 10.1.3 Conflict Resolution

```
Node-level conflict strategy:
  ├── Node position: last-write-wins (both users see node jump)
  ├── Node content: version check — if stale, show conflict dialog
  ├── Node deletion: if another user has it selected, warn before delete
  ├── Edge creation: allow (no conflict possible)
  └── Edge deletion: allow with undo support

Conflict dialog:
  "Another user modified this node while you were editing it."
  [Keep Mine] [Keep Theirs] [View Diff]
```

---

## 10.2 Sharing Improvements

### Current State
- Canvas sharing via connections (user-to-user)
- Blueprint sharing via connections
- Shared document access via `/api/shared/document/:id`

### 10.2.1 Link-Based Sharing

```typescript
// Share via link (no connection required)
// POST /api/share/create
// Returns: { shareId: "abc123", url: "/shared/abc123" }

export const shareLinks = pgTable("share_links", {
  id: text("id").primaryKey(),  // Short unique ID
  documentId: integer("document_id").notNull(),
  createdBy: text("created_by").notNull(),
  permission: text("permission").notNull().default("view"), // view | comment | edit
  expiresAt: timestamp("expires_at"),  // Optional expiration
  password: text("password"),  // Optional password protection
  accessCount: integer("access_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});
```

### 10.2.2 Permission Levels

| Level | Can View | Can Comment | Can Edit | Can Share |
|-------|----------|-------------|----------|-----------|
| Viewer | Yes | No | No | No |
| Commenter | Yes | Yes | No | No |
| Editor | Yes | Yes | Yes | No |
| Owner | Yes | Yes | Yes | Yes |

### 10.2.3 Public/Embed Mode

```typescript
// Read-only public view of a canvas (for portfolios, presentations)
// /public/canvas/:shareId

function PublicCanvasView({ shareId }) {
  // Read-only canvas rendering
  // No dock, no editing tools
  // Optional: "Made with Provocations" watermark
  // Optional: "Try it yourself" CTA
}
```

---

## 10.3 Team Workspaces

### 10.3.1 Team Model

```typescript
export const teams = pgTable("teams", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  ownerId: text("owner_id").notNull(),  // Clerk userId
  plan: text("plan").notNull().default("team"),
  maxMembers: integer("max_members").default(10),
  createdAt: timestamp("created_at").defaultNow(),
});

export const teamMembers = pgTable("team_members", {
  id: serial("id").primaryKey(),
  teamId: integer("team_id").notNull(),
  userId: text("user_id").notNull(),
  role: text("role").notNull().default("member"), // owner | admin | member
  joinedAt: timestamp("joined_at").defaultNow(),
});

export const teamCanvases = pgTable("team_canvases", {
  id: serial("id").primaryKey(),
  teamId: integer("team_id").notNull(),
  canvasId: integer("canvas_id").notNull(),  // documents table
  addedBy: text("added_by").notNull(),
  addedAt: timestamp("added_at").defaultNow(),
});
```

### 10.3.2 Team Features

```
Team Workspace:
  ├── Shared canvas library (all team members can see)
  ├── Shared context store (team-level documents)
  ├── Shared blueprints
  ├── Team activity feed
  ├── Member management (invite, remove, change role)
  ├── Team-level usage analytics
  └── Shared persona customizations
```

---

## 10.4 Comments & Annotations

### 10.4.1 Canvas Comments

```typescript
// Comments attached to specific canvas positions or nodes
export const canvasComments = pgTable("canvas_comments", {
  id: serial("id").primaryKey(),
  canvasId: integer("canvas_id").notNull(),
  userId: text("user_id").notNull(),
  content: text("content").notNull(),
  // Position: either on a node or at a canvas coordinate
  nodeId: text("node_id"),              // If attached to a node
  canvasX: real("canvas_x"),            // If at a canvas position
  canvasY: real("canvas_y"),
  resolved: boolean("resolved").default(false),
  parentCommentId: integer("parent_comment_id"), // For threads
  createdAt: timestamp("created_at").defaultNow(),
});
```

### 10.4.2 Comment UI

```
Canvas comment:
  ├── Click anywhere on canvas → Add comment (speech bubble icon)
  ├── Comments show as small bubbles on canvas
  ├── Click bubble → Open comment thread
  ├── Reply to comments
  ├── Resolve comments (dimmed, toggleable visibility)
  └── Filter: show all / unresolved / mine
```

---

## 10.5 Task Checklist

| # | Task | Priority | Status | Dependencies |
|---|------|----------|--------|-------------|
| 10.1.1 | WebSocket collaboration server | P1 | TODO | — |
| 10.1.2 | Presence UI (avatars + cursors) | P1 | TODO | 10.1.1 |
| 10.1.3 | Conflict resolution (node-level) | P1 | TODO | 10.1.1 |
| 10.2.1 | Link-based sharing | P1 | TODO | — |
| 10.2.2 | Permission levels | P1 | TODO | 10.2.1 |
| 10.2.3 | Public/embed view | P2 | TODO | 10.2.1 |
| 10.3.1 | Team data model | P1 | TODO | Track 6 (team tier) |
| 10.3.2 | Team workspace UI | P1 | TODO | 10.3.1 |
| 10.4.1 | Canvas comments data model | P2 | TODO | — |
| 10.4.2 | Comment UI | P2 | TODO | 10.4.1 |
