# Track 3: Security & Compliance

**Parent:** [the_v1_plan.md](./the_v1_plan.md)
**Priority:** Critical
**Milestone:** M2 (v0.20–v0.24)

---

## 3.1 OWASP Top 10 Review

### 3.1.1 Injection (A03:2021)

**Current state:** Zod validation on all API inputs. No raw SQL — Drizzle ORM parameterizes queries.

**Action items:**
- [ ] Audit all `db.execute(sql`...`)` calls for raw SQL injection vectors
- [ ] Verify Zod schemas reject unexpected fields (`.strict()` where appropriate)
- [ ] Review any template string interpolation in LLM prompts (prompt injection)
- [ ] Add input length limits to all text fields in Zod schemas

### 3.1.2 Broken Authentication (A07:2021)

**Current state:** Clerk handles auth. All document endpoints verify `req.auth.userId`.

**Action items:**
- [ ] Verify EVERY endpoint checks authentication (audit `server/routes.ts`)
- [ ] Ensure admin endpoints check admin role, not just auth
- [ ] Add session timeout configuration
- [ ] Review Clerk webhook handling for account deletion

### 3.1.3 Sensitive Data Exposure (A02:2021)

**Current state:** AES-256-GCM encryption at rest. Good foundation.

**Action items:**
- [ ] Verify no plaintext user content in server logs
- [ ] Ensure error messages don't leak internal paths or stack traces to client
- [ ] Audit LLM API calls — are we sending user content to third-party APIs? (Yes, by design — document this clearly)
- [ ] Ensure API keys never appear in client-side code or responses
- [ ] Review `console.log` statements for sensitive data

### 3.1.4 XML External Entities / SSRF

**Current state:** No XML parsing. YouTube API and LLM API calls go to known hosts.

**Action items:**
- [ ] Verify YouTube URL validation rejects non-YouTube URLs
- [ ] Ensure no user-controlled URLs are fetched server-side without validation
- [ ] Review WebFetch usage patterns

### 3.1.5 Broken Access Control (A01:2021)

**Current state:** Document ownership checked via userId. Shared items use sharedItems table.

**Action items:**
- [ ] **Critical:** Audit all endpoints for IDOR (Insecure Direct Object Reference)
  - Can user A access user B's document by guessing the ID?
  - Can user A delete user B's folder?
  - Can a non-admin hit admin endpoints?
- [ ] Add ownership verification to ALL document/folder PATCH/DELETE endpoints
- [ ] Review shared document access — is the sharing token validated correctly?
- [ ] Add rate limiting to prevent enumeration attacks on document IDs

### 3.1.6 Security Misconfiguration (A05:2021)

**Action items:**
- [ ] Add security headers (see 3.2)
- [ ] Disable Express `x-powered-by` header
- [ ] Review CORS configuration
- [ ] Ensure production doesn't serve source maps

---

## 3.2 Security Headers

```typescript
// server/middleware/security.ts
import helmet from "helmet";

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "https://clerk.com", "https://*.clerk.accounts.dev"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:", "blob:", "https://*.clerk.com"],
      connectSrc: [
        "'self'",
        "https://*.clerk.accounts.dev",
        "https://generativelanguage.googleapis.com",
        "https://api.openai.com",
        "https://api.anthropic.com",
        "https://api.elevenlabs.io",
        "wss://api.elevenlabs.io",
      ],
      mediaSrc: ["'self'", "blob:"],
      workerSrc: ["'self'", "blob:"],
    },
  },
  crossOriginEmbedderPolicy: false, // Needed for Clerk
  crossOriginResourcePolicy: { policy: "cross-origin" },
}));

// Additional headers
app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader("Permissions-Policy", "camera=(), microphone=(self), geolocation=()");
  next();
});
```

---

## 3.3 Rate Limiting

**Current state:** No rate limiting. Any authenticated user can make unlimited API calls.

### Implementation

```typescript
// server/middleware/rate-limit.ts
import rateLimit from "express-rate-limit";

// General API rate limit
export const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,  // 15 minutes
  max: 500,                    // 500 requests per window
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => req.auth?.userId || req.ip,
  message: { error: "Too many requests, please try again later" },
});

// LLM endpoint rate limit (expensive operations)
export const llmLimiter = rateLimit({
  windowMs: 60 * 1000,   // 1 minute
  max: 20,                // 20 LLM calls per minute
  keyGenerator: (req) => req.auth?.userId || req.ip,
  message: { error: "AI request limit reached. Please wait a moment." },
});

// Auth endpoint rate limit (prevent brute force)
export const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 50,
  keyGenerator: (req) => req.ip,
});

// File upload rate limit
export const uploadLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,  // 1 hour
  max: 50,                     // 50 uploads per hour
  keyGenerator: (req) => req.auth?.userId || req.ip,
});
```

### Apply to Routes

```typescript
// LLM-calling endpoints
app.post("/api/generate-challenges", llmLimiter, ...);
app.post("/api/generate-advice", llmLimiter, ...);
app.post("/api/write", llmLimiter, ...);
app.post("/api/write/stream", llmLimiter, ...);
app.post("/api/chat/stream", llmLimiter, ...);
app.post("/api/interview/question/stream", llmLimiter, ...);
app.post("/api/generate-image", llmLimiter, ...);

// File uploads
app.post("/api/upload", uploadLimiter, ...);

// Everything else
app.use("/api/", generalLimiter);
```

---

## 3.4 Encryption Audit

### Current Implementation Review

**Strengths:**
- AES-256-GCM (authenticated encryption)
- Per-field random salt + IV
- Server-side encryption at route boundary
- Master key caching for performance (v0.16.0)

**Concerns to Investigate:**
- [ ] Is ENCRYPTION_SECRET strong enough? (entropy check)
- [ ] Key rotation strategy — what happens if we need to change the key?
- [ ] Are there any code paths where plaintext is written to DB?
- [ ] Is the legacy plaintext fallback a security risk?
- [ ] PBKDF2 iteration count — is it sufficient? (OWASP recommends 600,000 for SHA-256)
- [ ] Are salt + IV values stored separately or concatenated? (verify no reuse)

### Key Rotation Plan

```typescript
// Pseudocode for key rotation
// 1. Add new env var: ENCRYPTION_SECRET_NEW
// 2. Decrypt with old key, re-encrypt with new key
// 3. Batch process in background

async function rotateKeys(oldSecret, newSecret) {
  const documents = await db.select().from(documentsTable);

  for (const doc of documents) {
    if (!doc.contentCiphertext) continue; // Skip legacy plaintext

    // Decrypt with old key
    const plaintext = decrypt(doc.contentCiphertext, doc.contentSalt, doc.contentIv, oldSecret);

    // Re-encrypt with new key (generates new salt + IV)
    const { ciphertext, salt, iv } = encrypt(plaintext, newSecret);

    // Update in DB
    await db.update(documentsTable)
      .set({ contentCiphertext: ciphertext, contentSalt: salt, contentIv: iv })
      .where(eq(documentsTable.id, doc.id));
  }
}
```

---

## 3.5 Input Validation Hardening

### Field Length Limits

```typescript
// Add to Zod schemas in shared/schema.ts
const MAX_DOCUMENT_CONTENT = 500_000;  // ~500K chars (~125K tokens)
const MAX_TITLE = 500;
const MAX_OBJECTIVE = 2000;
const MAX_NOTE = 10_000;
const MAX_CHAT_MESSAGE = 5000;
const MAX_FOLDER_NAME = 200;

// Example hardened schema
export const writeRequestSchema = z.object({
  content: z.string().max(MAX_DOCUMENT_CONTENT),
  instruction: z.string().max(MAX_OBJECTIVE),
  tone: z.enum(toneOptions),
  appType: z.enum(templateIds),
  // ... etc
});
```

### File Upload Validation

```typescript
// Beyond size limit (already 50MB), validate:
// - File type (magic bytes, not just extension)
// - Image dimensions (prevent decompression bombs)
// - No executable content
// - Sanitize filenames

const ALLOWED_MIME_TYPES = [
  "image/png", "image/jpeg", "image/gif", "image/webp",
  "video/mp4", "video/webm",
  "application/pdf",
  "text/plain", "text/markdown",
];

function validateUpload(file) {
  if (!ALLOWED_MIME_TYPES.includes(file.mimetype)) {
    throw new Error("File type not allowed");
  }
  // Check magic bytes match declared mime type
  // Reject files with embedded scripts
}
```

---

## 3.6 LLM Security (Prompt Injection)

### Current Risks
- User content is injected into LLM prompts (by design)
- Persona challenge/advice prompts include user document content
- Research chat sends user messages + context to LLM
- Chain execution passes user content between nodes

### Mitigations

```typescript
// 1. Separate system/user content in LLM calls
// Always use the "system" role for instructions, "user" role for user content
// Never concatenate system + user content into a single string

// 2. Output validation
// Validate LLM output before acting on it
// Don't execute code returned by LLM
// Don't follow URLs returned by LLM

// 3. Sandboxed context
// Chain execution should not allow one node's LLM output to
// modify the system prompt of downstream nodes
```

---

## 3.7 Task Checklist

| # | Task | Priority | Status | Dependencies |
|---|------|----------|--------|-------------|
| 3.1.1 | OWASP injection audit | P0 | TODO | — |
| 3.1.2 | Auth completeness audit | P0 | TODO | — |
| 3.1.5 | IDOR audit on all endpoints | P0 | TODO | — |
| 3.2.1 | Add helmet + security headers | P0 | TODO | — |
| 3.3.1 | Add rate limiting middleware | P0 | TODO | — |
| 3.3.2 | Apply rate limits to LLM endpoints | P0 | TODO | 3.3.1 |
| 3.4.1 | Encryption implementation audit | P1 | TODO | — |
| 3.4.2 | Design key rotation strategy | P2 | TODO | 3.4.1 |
| 3.5.1 | Add field length limits to all schemas | P1 | TODO | — |
| 3.5.2 | Harden file upload validation | P1 | TODO | — |
| 3.6.1 | LLM prompt injection review | P1 | TODO | — |
| 3.6.2 | Output validation on LLM responses | P2 | TODO | — |
