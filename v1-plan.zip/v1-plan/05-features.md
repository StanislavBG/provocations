# Track 5: Core Feature Completion

**Parent:** [the_v1_plan.md](./the_v1_plan.md)
**Priority:** High
**Milestone:** M2–M3

---

## 5.1 Node Type Audit

Every node type needs to work reliably end-to-end: compact view, expanded view, chain execution, save/load, blueprint inclusion.

### Current Node Status Matrix

| Node Type | Compact | Expanded | Chain Exec | Save/Load | Edge Roles | Status |
|-----------|---------|----------|------------|-----------|------------|--------|
| research | Good | Good | Good | Good | Yes | **Ready** |
| interview | Good | Good | Good | Good | Yes | **Ready** |
| llm | Good | Good | Good | Good | Yes | **Ready** |
| llm-base | Good | Good | Good | Good | Yes | **Ready** |
| painter | Good | Good | Good | Good | Partial | Needs role support |
| youtube | Good | Good | Good | Good | No | Needs role support |
| audio | Good | Good | Good | Good | No | **Ready** |
| context-doc | Good | Basic | N/A (passive) | Good | N/A | Expand view needs work |
| store | Good | Good | N/A (passive) | Good | N/A | **Ready** |
| upload | Good | Good | N/A (passive) | Good | N/A | **Ready** |
| document | Good | Good | Good | Good | Yes | **Ready** |
| timer-event | Good | Good | Good | Good | N/A | **Ready** |
| social-post | Good | Good | Good | Good | Partial | Needs image flow cleanup |
| api-connection | Good | Good | Good | Good | No | Needs role support |
| notification | Good | Good | Good | Good | No | **Ready** |
| approval | Good | Good | Good | Good | No | **Ready** |
| label | Good | Inline | N/A (visual) | Good | N/A | **Ready** |
| zone | Good | None | N/A (visual) | Good | N/A | **Ready** |
| filter | Good | Good | Good | Good | No | **Ready** |
| gate | Good | Good | Good | Good | No | **Ready** |
| router | Good | Good | Good | Good | No | **Ready** |
| merge | Good | Good | Good | Good | No | **Ready** |
| coherence-gate | Good | Good | Good | Good | No | **Ready** |

### Gaps to Fill

#### 5.1.1 Context-Doc Expanded View
Currently just shows label + content in a basic editor. Should show:
- Document preview with markdown rendering
- "Open in Context Store" button
- Version history if available
- Related connections on canvas

#### 5.1.2 Edge Role Expansion
Several node types don't support edge roles yet:
- `youtube` — should accept `objective` (what to search for) and `context` (background info)
- `api-connection` — should accept `context` (API documentation or specs)
- `painter` — needs full role support (objective = what to paint, context = style reference)

#### 5.1.3 Social Post Image Pipeline
The image flow from painter → social post works but has rough edges:
- Sometimes images duplicate
- Platform-specific image requirements not enforced
- No image preview in compact card

---

## 5.2 Chain Execution Reliability

### Known Issues

#### 5.2.1 Race Conditions
- Two upstream nodes completing simultaneously can trigger duplicate execution
- Re-entrance guard exists but timing-dependent
- **Fix:** Add execution lock per node with queue for pending triggers

#### 5.2.2 Error Recovery
- If a node fails mid-chain, downstream nodes hang in "waiting" state
- No retry mechanism
- No way to resume a failed chain from the point of failure
- **Fix:** Add error state propagation + retry button on failed nodes

#### 5.2.3 Long-Running Chains
- No progress indicator for chains with 10+ nodes
- No timeout for individual node execution
- Activity log exists but hard to follow for complex chains
- **Fix:** Chain progress bar in status area, per-node timeout (configurable)

### Desired Chain Behaviors

```
Chain error handling:
  Node fails →
    ├── Mark node as "error" (red border, error icon)
    ├── Propagate "error" status to all downstream nodes
    ├── Show error message on node hover
    ├── Show "Retry" button on failed node
    ├── User clicks Retry → re-run just that node
    └── On success → resume chain from that point

Chain progress:
  Chain starts →
    ├── Show progress bar: "Processing 3/8 nodes"
    ├── Highlight current node(s) being processed
    ├── Show estimated time remaining (based on node types)
    └── Allow cancel (stops processing, marks remaining as "cancelled")
```

---

## 5.3 Document Editor Enhancements

### 5.3.1 Rich Text Editing

**Current:** Plain markdown textarea with smart buttons (Expand/Condense/etc.)

**Target:** Still markdown-based, but with:
- Inline formatting toolbar (bold, italic, heading shortcuts)
- Live markdown preview (split or toggle)
- Drag-drop image insertion (from painter nodes or upload)
- Table insertion helper
- Code block syntax highlighting

### 5.3.2 Version History

**Current:** Version count shown in top bar. Versions stored but no diff view.

**Target:**
```
Version History Panel:
  ├── Version list with timestamps and change summaries
  ├── Diff view (side-by-side or inline, unified diff)
  ├── Restore to previous version
  ├── Branch from version (create new document from old state)
  └── Auto-version on significant changes (not every keystroke)
```

### 5.3.3 Export Improvements

**Current:** Markdown + PDF download exists.

**Target additions:**
- Word document (.docx) export
- HTML export with styling
- Export with images embedded
- Export entire canvas as a project package (ZIP with all documents)

---

## 5.4 Context Store Improvements

### 5.4.1 Search & Filter

```
Context Store search:
  ├── Full-text search across document content (server-side decrypt + search)
  ├── Filter by document type (markdown, image, video, pdf)
  ├── Filter by date range
  ├── Sort by name, date, size, type
  └── Tag-based filtering (add tagging system)
```

### 5.4.2 Bulk Operations

- Multi-select documents for bulk delete, move, tag
- Bulk export (ZIP download)
- Bulk share (share folder with all contents)

### 5.4.3 Document Tagging

```typescript
// New: tags table
// tags: id, name, color, userId
// document_tags: documentId, tagId

// UI: tag chips on documents, tag filter in sidebar
// Auto-suggest tags based on content
```

---

## 5.5 Interview Mode Refinements

### 5.5.1 Interview Templates

Pre-built interview structures for common use cases:
- Product discovery interview
- User research interview
- Technical requirements gathering
- Brainstorming session
- Retrospective / lessons learned

### 5.5.2 Interview Summary Improvements

Current summary is a single AI-generated text. Improve to:
- Structured output (key themes, decisions, action items, open questions)
- Export as formatted brief
- Auto-generate follow-up interview questions
- Cross-reference with existing context documents

### 5.5.3 Multi-Participant Interview

Future: allow multiple users to participate in same interview session
- Round-robin questions
- Role assignment (interviewer/interviewee/observer)
- Merged transcript with speaker labels

---

## 5.6 Persona System Upgrades

### 5.6.1 Custom Personas

**Current:** 14 built-in personas. Users can't create their own.

**Target:**
- User-created personas with custom prompts
- Persona templates (clone + modify built-in)
- Persona sharing between users
- Persona marketplace (future)

### 5.6.2 Persona Tuning

- Per-document persona weight adjustment (some perspectives matter more for certain docs)
- "Favorite personas" that auto-enable for new sessions
- Persona response length control (brief/standard/detailed)

---

## 5.7 Task Checklist

| # | Task | Priority | Status | Dependencies |
|---|------|----------|--------|-------------|
| 5.1.1 | Context-doc expanded view upgrade | P1 | TODO | — |
| 5.1.2 | Edge role support for youtube, api, painter | P1 | TODO | — |
| 5.1.3 | Social post image pipeline cleanup | P2 | TODO | — |
| 5.2.1 | Chain execution lock + queue | P0 | TODO | — |
| 5.2.2 | Chain error recovery + retry | P0 | TODO | — |
| 5.2.3 | Chain progress indicator | P1 | TODO | — |
| 5.3.1 | Rich text editing (inline toolbar) | P2 | TODO | — |
| 5.3.2 | Version history with diff view | P1 | TODO | — |
| 5.3.3 | Export improvements (docx, html, zip) | P2 | TODO | — |
| 5.4.1 | Context Store search & filter | P1 | TODO | — |
| 5.4.2 | Bulk operations | P2 | TODO | — |
| 5.4.3 | Document tagging system | P2 | TODO | — |
| 5.5.1 | Interview templates | P2 | TODO | — |
| 5.5.2 | Structured interview summaries | P1 | TODO | — |
| 5.5.3 | Multi-participant interview | P2 | TODO | Track 10 |
| 5.6.1 | Custom user personas | P1 | TODO | — |
| 5.6.2 | Persona tuning controls | P2 | TODO | 5.6.1 |
