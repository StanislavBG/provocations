# Track 7: Infrastructure & DevOps

**Parent:** [the_v1_plan.md](./the_v1_plan.md)
**Priority:** High
**Milestone:** M1 (CI/CD) + M3 (staging, backups)

---

## 7.1 CI/CD Pipeline

**Current state:** No CI/CD. Code is pushed to GitHub, manually synced to Replit, manually deployed.

### 7.1.1 GitHub Actions Pipeline

```yaml
# .github/workflows/ci.yml
name: CI

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  lint-and-type-check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: npm
      - run: npm ci
      - run: npm run check          # TypeScript type checking
      - run: npx eslint . --ext .ts,.tsx  # If we add ESLint

  test:
    runs-on: ubuntu-latest
    needs: lint-and-type-check
    services:
      postgres:
        image: postgres:16
        env:
          POSTGRES_USER: test
          POSTGRES_PASSWORD: test
          POSTGRES_DB: provocations_test
        ports:
          - 5432:5432
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: npm
      - run: npm ci
      - run: npx vitest run
        env:
          DATABASE_URL: postgresql://test:test@localhost:5432/provocations_test
          ENCRYPTION_SECRET: test-secret-for-ci-only

  build:
    runs-on: ubuntu-latest
    needs: test
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: npm
      - run: npm ci
      - run: npm run build
      # Upload build artifacts for deployment
```

### 7.1.2 Pre-commit Hooks

```bash
# .husky/pre-commit
npm run check
```

### 7.1.3 PR Checks

Required checks before merge:
- TypeScript type check passes
- All tests pass
- Build succeeds
- No new `any` types in changed files (custom ESLint rule)

---

## 7.2 Staging Environment

**Current state:** Only production (Replit). No staging.

### Options

#### Option A: Replit Dev Deployment
- Use Replit's "Dev" deployment slot
- Same infrastructure, separate URL
- Shares database (use separate schema or DB)

#### Option B: Docker Compose Local Staging
```yaml
# docker-compose.staging.yml
services:
  app:
    build: .
    ports:
      - "5000:5000"
    environment:
      - DATABASE_URL=postgresql://postgres:postgres@db:5432/provocations
      - ENCRYPTION_SECRET=${STAGING_ENCRYPTION_SECRET}
      - NODE_ENV=staging
    depends_on:
      - db

  db:
    image: postgres:16
    volumes:
      - staging_data:/var/lib/postgresql/data
    environment:
      - POSTGRES_DB=provocations
      - POSTGRES_PASSWORD=postgres

volumes:
  staging_data:
```

**Recommendation:** Start with Option A (Replit Dev) for simplicity. Move to Docker when team grows.

---

## 7.3 Structured Logging

### 7.3.1 Log Levels

```typescript
// server/logger.ts
enum LogLevel { DEBUG, INFO, WARN, ERROR }

interface LogEntry {
  level: LogLevel;
  message: string;
  timestamp: string;
  requestId?: string;
  userId?: string;
  duration?: number;
  error?: {
    message: string;
    stack?: string;
    code?: string;
  };
  metadata?: Record<string, unknown>;
}

function log(entry: LogEntry) {
  // In production: JSON output for log aggregation
  // In development: pretty-printed for readability
  if (process.env.NODE_ENV === "production") {
    console.log(JSON.stringify(entry));
  } else {
    console.log(`[${entry.level}] ${entry.message}`, entry.metadata || "");
  }
}
```

### 7.3.2 Request Correlation

```typescript
// Assign a unique ID to each request for tracing
import { randomUUID } from "crypto";

app.use((req, res, next) => {
  req.requestId = req.headers["x-request-id"] || randomUUID();
  res.setHeader("x-request-id", req.requestId);
  next();
});
```

### 7.3.3 LLM Call Logging (Already Exists)

`server/llm-gateway.ts` already logs LLM calls with cost tracking. Enhance:
- Add request correlation ID
- Log prompt token count vs. completion token count
- Track latency percentiles (p50, p95, p99)
- Alert on error rate spikes

---

## 7.4 Health Checks & Monitoring

### 7.4.1 Health Endpoint

```typescript
// GET /api/health
app.get("/api/health", async (req, res) => {
  const checks = {
    server: "ok",
    database: "checking",
    llm: "checking",
    timestamp: new Date().toISOString(),
    version: APP_VERSION,
    uptime: process.uptime(),
  };

  // Database check
  try {
    await db.execute(sql`SELECT 1`);
    checks.database = "ok";
  } catch (e) {
    checks.database = "error";
  }

  // LLM provider check (cached, check every 5 min)
  checks.llm = await checkLlmProvider();

  const allOk = Object.values(checks).every(v => v === "ok" || typeof v !== "string");
  res.status(allOk ? 200 : 503).json(checks);
});
```

### 7.4.2 Uptime Monitoring

- Use a free uptime service (UptimeRobot, Better Uptime) to ping `/api/health`
- Alert on downtime via email/Slack
- Track response time trends

---

## 7.5 Database Management

### 7.5.1 Backup Strategy

```bash
# Daily automated backup via cron (or Replit scheduled task)
pg_dump $DATABASE_URL | gzip > "backup_$(date +%Y%m%d_%H%M%S).sql.gz"

# Upload to cloud storage (S3/GCS/R2)
# Retain: daily for 7 days, weekly for 4 weeks, monthly for 12 months
```

### 7.5.2 Migration Safety

Current dual-schema system (ensureTables + Drizzle) is documented in CLAUDE.md. For v1.0:
- Consider dropping `ensureTables()` in favor of Drizzle-only migrations
- Add migration tests to CI (apply migrations to empty DB, verify schema)
- Add rollback scripts for critical migrations

### 7.5.3 Connection Pool Tuning

```typescript
// Current: reduced pool size for Replit
// Target: dynamic pool sizing based on load

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: process.env.NODE_ENV === "production" ? 20 : 5,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
});
```

---

## 7.6 Environment Variable Management

### Current env vars (from CLAUDE.md):

```
Required:
  GEMINI_API_KEY              # Primary LLM provider
  DATABASE_URL                # PostgreSQL
  ENCRYPTION_SECRET           # AES-GCM key
  CLERK_PUBLISHABLE_KEY       # Auth (frontend)
  CLERK_SECRET_KEY            # Auth (backend)

Optional:
  ANTHROPIC_API_KEY           # Alternate LLM
  OPENAI_API_KEY              # Not used (per CLAUDE.md rules)
  YOUTUBE_API_KEY             # YouTube Data API
  ELEVENLABS_API_KEY          # TTS
  ELEVENLABS_VOICE_ID         # Default voice
  LLM_PROVIDER                # Force provider selection
  PLAYWRIGHT_CHROMIUM_PATH    # Screenshots
  AIQA_URL                    # QA overlay
  AIQA_API_KEY                # QA API
  AIQA_PROJECT_ID             # QA project

Future (Stripe):
  STRIPE_SECRET_KEY           # Billing
  STRIPE_WEBHOOK_SECRET       # Webhook verification
  STRIPE_PUBLISHABLE_KEY      # Client-side
```

### Validation at Startup

```typescript
// server/env.ts — validate required env vars on startup
const requiredVars = [
  "DATABASE_URL",
  "ENCRYPTION_SECRET",
  "CLERK_SECRET_KEY",
];

for (const varName of requiredVars) {
  if (!process.env[varName]) {
    console.error(`Missing required environment variable: ${varName}`);
    process.exit(1);
  }
}

// Warn about missing optional vars
const optionalVars = ["GEMINI_API_KEY", "YOUTUBE_API_KEY", "ELEVENLABS_API_KEY"];
for (const varName of optionalVars) {
  if (!process.env[varName]) {
    console.warn(`Optional env var ${varName} not set — related features disabled`);
  }
}
```

---

## 7.7 Task Checklist

| # | Task | Priority | Status | Dependencies |
|---|------|----------|--------|-------------|
| 7.1.1 | GitHub Actions CI pipeline | P0 | TODO | Track 1 (tests) |
| 7.1.2 | Pre-commit hooks (husky) | P1 | TODO | — |
| 7.1.3 | PR required checks | P1 | TODO | 7.1.1 |
| 7.2.1 | Staging environment setup | P1 | TODO | — |
| 7.3.1 | Structured logging system | P1 | TODO | — |
| 7.3.2 | Request correlation IDs | P1 | TODO | 7.3.1 |
| 7.4.1 | Health check endpoint | P0 | TODO | — |
| 7.4.2 | Uptime monitoring setup | P1 | TODO | 7.4.1 |
| 7.5.1 | Database backup automation | P0 | TODO | — |
| 7.5.2 | Migration safety tests | P1 | TODO | Track 1 |
| 7.5.3 | Connection pool tuning | P2 | TODO | — |
| 7.6.1 | Env var validation at startup | P1 | TODO | — |
