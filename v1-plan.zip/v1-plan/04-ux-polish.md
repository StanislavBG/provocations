# Track 4: User Experience & Polish

**Parent:** [the_v1_plan.md](./the_v1_plan.md)
**Priority:** High
**Milestone:** M2 (v0.20–v0.24)

---

## 4.1 Onboarding & First-Run Experience

**Current state:** New users land on a blank canvas with a dock. FTUX status bar exists but no guided tutorial. The product is powerful but not self-explanatory.

### 4.1.1 First-Time User Flow

```
User signs up → Clerk auth → Lands on canvas
                                    ↓
                    ┌─────────────────────────────────┐
                    │   Welcome Overlay (one-time)    │
                    │                                 │
                    │   "Provocations helps you       │
                    │   think deeper and build         │
                    │   smarter documents."            │
                    │                                 │
                    │   [Start Guided Tour]            │
                    │   [Explore on My Own]            │
                    │   [Load a Blueprint]             │
                    └─────────────────────────────────┘
```

### 4.1.2 Guided Tour (Step-by-Step)

```typescript
// Tour steps using a lightweight spotlight/tooltip system
const TOUR_STEPS = [
  {
    target: ".ftux-dock",
    title: "Your Toolbox",
    content: "Drag tools from here onto the canvas to build your workflow.",
    placement: "right",
  },
  {
    target: ".flow-canvas",
    title: "The Canvas",
    content: "This is your workspace. Pan with WASD or middle-click. Zoom with scroll wheel.",
    placement: "center",
  },
  {
    target: "[data-tool='research']",
    title: "Research",
    content: "Start here — ask questions, explore ideas. The AI helps you dig deeper.",
    placement: "right",
  },
  {
    target: "[data-tool='context']",
    title: "Context",
    content: "Load documents and files to give the AI context about your project.",
    placement: "right",
  },
  {
    target: "[data-tool='llm']",
    title: "Text Mods",
    content: "Transform text — summarize, expand, clean up, or run custom instructions.",
    placement: "right",
  },
  {
    target: ".connection-port",
    title: "Connect Nodes",
    content: "Drag from one node's output port to another's input to create a flow.",
    placement: "top",
  },
  {
    target: ".blueprints-button",
    title: "Blueprints",
    content: "Not sure where to start? Load a pre-built workflow blueprint.",
    placement: "bottom",
  },
];
```

### 4.1.3 Blueprint-First Onboarding

For users who skip the tour, suggest a blueprint:
- "Research & Write" — research node → LLM node → document
- "Interview to Brief" — interview node → LLM node → document
- "Content Pipeline" — context → LLM → social post

### 4.1.4 Empty State Improvements

Every empty panel should tell the user what to do:
- Empty canvas: "Drag a tool from the dock to get started, or load a Blueprint"
- Empty research chat: "Ask a question to start researching"
- Empty document node: "Type your content or connect an upstream node"
- Empty context sidebar: "Pin documents from the Context Store to use as AI context"

---

## 4.2 Accessibility (WCAG 2.1 AA)

**Current state:** No accessibility audit has been done. Canvas is heavily mouse-dependent.

### 4.2.1 Keyboard Navigation

| Area | Current | Target |
|------|---------|--------|
| Canvas pan | WASD (good) | + Arrow keys |
| Node selection | Click only | Tab through nodes, Enter to select |
| Dock items | Click/drag only | Tab to dock, Enter to place at center |
| Expanded overlay | ESC to close (good) | Tab order within overlay |
| Menu bar | Click to open | Alt+key mnemonics |
| Context sidebar | Mouse-only tree | Arrow keys for tree navigation |

### 4.2.2 Screen Reader Support

```typescript
// Add ARIA labels to key interactive elements
<div role="application" aria-label="Flow Canvas">
  <div role="toolbar" aria-label="Tool Dock">
    <button aria-label="Add Research node" role="menuitem">
      <Sparkles /> Research
    </button>
  </div>

  {nodes.map(node => (
    <div
      key={node.id}
      role="article"
      aria-label={`${node.type} node: ${node.label}`}
      aria-selected={isSelected}
      tabIndex={0}
    >
      ...
    </div>
  ))}
</div>
```

### 4.2.3 Color Contrast

- Audit all text against backgrounds for 4.5:1 contrast ratio (AA)
- Canvas themes (Default, Dark, Aurora) all need contrast audit
- Node status indicators need non-color alternatives (icons/patterns)

### 4.2.4 Motion & Reduced Motion

```css
@media (prefers-reduced-motion: reduce) {
  /* Disable node pulsing animations */
  .node-pulse { animation: none; }
  /* Disable aurora background animation */
  .aurora-bg { animation: none; }
  /* Disable smooth pan/zoom transitions */
  .canvas-container { transition: none; }
}
```

---

## 4.3 Responsive Design & Mobile

**Current state:** NotebookWorkspace has mobile fallback (tabbed layout). FlowWorkspace (the primary canvas view) is desktop-only.

### 4.3.1 Mobile Canvas Strategy

Full canvas editing on mobile isn't realistic. Instead:

```
Mobile strategy:
  ├── Canvas View: read-only overview with zoom/pan (touch gestures)
  ├── Node List: vertical scrollable list of all nodes
  ├── Node Detail: tap a node → full-screen detail view (like expanded overlay)
  ├── Quick Actions: voice input, camera upload, note capture
  └── No node creation/connection on mobile (desktop for that)
```

### 4.3.2 Breakpoints

```css
/* Breakpoint strategy */
@media (max-width: 640px)   { /* Mobile: single column, no canvas */ }
@media (max-width: 1024px)  { /* Tablet: simplified canvas, collapsible panels */ }
@media (min-width: 1025px)  { /* Desktop: full canvas experience */ }
```

### 4.3.3 Touch Gestures (Tablet)

```typescript
// For tablet users who want to interact with the canvas
const touchHandlers = {
  onTouchStart: handlePanStart,
  onTouchMove: handlePanMove,
  onTouchEnd: handlePanEnd,
  // Pinch-to-zoom
  onPinch: handleZoom,
  // Long-press to select
  onLongPress: handleNodeSelect,
  // Double-tap to expand
  onDoubleTap: handleNodeExpand,
};
```

---

## 4.4 UX Consistency Pass

### 4.4.1 Loading States

Every async operation needs a consistent loading indicator:
- **Buttons:** Spinner icon + disabled state while loading
- **Panels:** Skeleton loader for content areas
- **Canvas nodes:** Pulsing animation during chain execution (already exists)
- **Full-page:** Branded loading screen on initial app load

### 4.4.2 Error States

Consistent error handling across all panels:
```typescript
// Standard error display component
function ErrorState({ title, message, onRetry }) {
  return (
    <div className="flex flex-col items-center gap-3 p-6 text-center">
      <AlertCircle className="text-red-500 w-8 h-8" />
      <h3 className="font-medium">{title}</h3>
      <p className="text-sm text-muted-foreground">{message}</p>
      {onRetry && (
        <Button variant="outline" size="sm" onClick={onRetry}>
          Try Again
        </Button>
      )}
    </div>
  );
}
```

### 4.4.3 Toast Notifications

Audit toast usage:
- Success toasts: brief, auto-dismiss in 3s
- Error toasts: persist until dismissed, include action to retry
- Info toasts: auto-dismiss in 5s
- Never stack more than 3 toasts

### 4.4.4 Confirmation Dialogs

Standardize destructive action confirmations:
- Delete node/document/canvas: always confirm
- Clear content: confirm if content > 100 chars
- Overwrite: always confirm
- Navigation away from unsaved changes: warn

---

## 4.5 Visual Polish

### 4.5.1 Animation Refinement

```css
/* Standardize transition timing */
:root {
  --transition-fast: 150ms ease-out;
  --transition-normal: 250ms ease-out;
  --transition-slow: 400ms ease-out;
}

/* Node hover */
.flow-node:hover { transform: translateY(-1px); box-shadow: ...; transition: var(--transition-fast); }

/* Panel open/close */
.panel-slide { transition: width var(--transition-normal); }

/* Overlay appear */
.overlay-enter { animation: fadeIn var(--transition-normal); }
```

### 4.5.2 Typography Consistency

- Audit all font usage against design system (Source Serif 4, Libre Baskerville, JetBrains Mono)
- Ensure consistent heading sizes across all panels
- Standardize code/monospace usage

### 4.5.3 Icon Consistency

- All node types should have consistent icon sizes
- Dock icons, compact node icons, and expanded view icons should match
- Audit for any hardcoded emoji usage (should use Lucide icons)

---

## 4.6 Task Checklist

| # | Task | Priority | Status | Dependencies |
|---|------|----------|--------|-------------|
| 4.1.1 | Welcome overlay for first-time users | P0 | TODO | — |
| 4.1.2 | Guided tour system (spotlight + tooltips) | P1 | TODO | 4.1.1 |
| 4.1.3 | Blueprint-first onboarding option | P1 | TODO | 4.1.1 |
| 4.1.4 | Empty state improvements across all panels | P1 | TODO | — |
| 4.2.1 | Keyboard navigation for canvas + dock | P1 | TODO | — |
| 4.2.2 | ARIA labels and screen reader support | P1 | TODO | — |
| 4.2.3 | Color contrast audit (all themes) | P1 | TODO | — |
| 4.2.4 | Reduced motion support | P2 | TODO | — |
| 4.3.1 | Mobile read-only canvas view | P2 | TODO | — |
| 4.3.2 | Responsive breakpoints for panels | P1 | TODO | — |
| 4.3.3 | Touch gesture support for tablet | P2 | TODO | — |
| 4.4.1 | Standardize loading states | P1 | TODO | — |
| 4.4.2 | Standardize error states | P1 | TODO | — |
| 4.4.3 | Toast notification audit | P2 | TODO | — |
| 4.4.4 | Destructive action confirmation audit | P1 | TODO | — |
| 4.5.1 | Animation timing standardization | P2 | TODO | — |
| 4.5.2 | Typography consistency audit | P2 | TODO | — |
| 4.5.3 | Icon consistency audit | P2 | TODO | — |
