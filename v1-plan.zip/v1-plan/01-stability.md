# Track 1: Stability & Quality

**Parent:** [the_v1_plan.md](./the_v1_plan.md)
**Priority:** Critical — this is the foundation everything else builds on
**Milestone:** M1 (v0.17–v0.19)

---

## 1.1 Testing Framework

**Status:** Not started
**Current state:** Zero test infrastructure. Only manual testing + 59 ad-hoc crypto/canvas compat tests added in v0.16.3.

### Setup

```
Framework: Vitest (already have Vite — natural fit)
DOM testing: @testing-library/react
API testing: supertest
E2E: Playwright (already have Chromium path configured)
Coverage target: 60% for v1.0, 80% long-term
```

### Test Categories & Priorities

#### P0 — Critical Path (must have for v1.0)

| Area | What to Test | Estimated Tests |
|------|-------------|-----------------|
| **Encryption round-trip** | encrypt → decrypt for all field types (title, content, folder name), legacy plaintext fallback, master-salt migration | ~25 |
| **API endpoints** | All POST/PUT/PATCH/DELETE routes with valid input, invalid input, missing auth, wrong user | ~80 |
| **LLM routing** | Provider selection (Gemini/OpenAI/Anthropic), fallback behavior, streaming vs non-streaming | ~15 |
| **Canvas serialization** | Save → load round-trip, node/edge integrity, unknown node type handling, version migration | ~30 |
| **Chain execution** | Linear chain, branching, merge (wait-all vs fire-each), logic gates (pass/fail), cycle detection | ~40 |
| **Edge roles** | Role assignment, multi-role edges, role-aware input gathering, system-instruction handling | ~20 |
| **Auth** | Clerk middleware, admin role checks, document ownership verification | ~15 |

#### P1 — Important (should have for v1.0)

| Area | What to Test | Estimated Tests |
|------|-------------|-----------------|
| **Component rendering** | All 17 node types render compact + expanded without crash | ~34 |
| **Persona system** | Challenge generation, advice generation, persona hierarchy validation | ~15 |
| **Context Store** | CRUD operations, folder hierarchy, pin/unpin, search | ~25 |
| **Document editor** | Write endpoint instruction classification, tone application, merge behavior | ~20 |
| **Blueprint system** | Save, load, share, apply blueprint to canvas | ~15 |

#### P2 — Nice to Have

| Area | What to Test | Estimated Tests |
|------|-------------|-----------------|
| **Voice** | Whisper hook state machine, transcript append, conversation turn management | ~15 |
| **Interview** | Question generation, stance selection, brainstorm mode state | ~20 |
| **Notification** | Send, receive, template placeholders | ~10 |
| **User messaging** | Connection invite, accept, message send/receive | ~15 |

### Test File Structure

```
tests/
  setup.ts                    # Vitest config, mocks, test DB
  helpers/
    auth.ts                   # Mock Clerk auth helpers
    db.ts                     # Test database setup/teardown
    llm.ts                    # Mock LLM responses
  unit/
    server/
      crypto.test.ts          # Encryption/decryption
      llm.test.ts             # Provider routing
      context-builder.test.ts # Prompt construction
      storage.test.ts         # DB operations
    shared/
      schema.test.ts          # Zod validation
    client/
      hooks/                  # Hook unit tests
      components/             # Component unit tests
  integration/
    api/
      documents.test.ts       # Document CRUD
      canvas.test.ts          # Canvas save/load
      chat.test.ts            # Research chat
      chain.test.ts           # Chain execution
  e2e/
    canvas-workflow.test.ts   # Full canvas creation → save → reload
    research-flow.test.ts     # Research chat → save to context → evolve doc
    interview-flow.test.ts    # Interview session end-to-end
```

### Pseudocode: Test Database Setup

```typescript
// tests/helpers/db.ts
import { drizzle } from "drizzle-orm/node-postgres";

const TEST_DB_URL = process.env.TEST_DATABASE_URL || "postgresql://...test";

export async function setupTestDb() {
  const db = drizzle(TEST_DB_URL);
  // Run ensureTables() against test DB
  // Seed with test user, test documents, test folders
  return db;
}

export async function teardownTestDb(db) {
  // Truncate all tables (order matters for FK constraints)
  // Close connection
}

// Per-test isolation: wrap each test in a transaction that rolls back
export function withTransaction(db, fn) {
  return db.transaction(async (tx) => {
    await fn(tx);
    throw new Error("ROLLBACK"); // Force rollback
  }).catch(e => {
    if (e.message !== "ROLLBACK") throw e;
  });
}
```

---

## 1.2 FlowWorkspace Decomposition

**Status:** Not started
**Current state:** `FlowWorkspace.tsx` is ~7800 lines — the single largest file in the codebase. It's the main orchestrator for the flow canvas and handles everything from dock config to overlay management to state wiring.

### Why This Matters
- Impossible to test in isolation
- Merge conflicts when multiple agents work on canvas features
- Slow IDE performance and poor code navigation
- High cognitive load for any developer

### Decomposition Strategy

Break into ~10 focused modules, each under 800 lines:

```
client/src/pages/
  FlowWorkspace.tsx           # ~300 lines — thin orchestrator, imports everything
  flow-workspace/
    FlowWorkspaceState.tsx    # ~500 lines — all useState/useRef/useCallback declarations
    FlowDockConfig.ts         # ~200 lines — FLOW_DOCK_ITEMS, dock handlers
    FlowOverlayManager.tsx    # ~800 lines — all expanded overlay rendering
    FlowToolHandlers.ts       # ~400 lines — tool activation, drop handlers
    FlowCanvasActions.ts      # ~300 lines — save, load, share, delete canvas
    FlowMenuBar.tsx           # ~400 lines — top menu bar with File/Edit/View
    FlowStatusBar.tsx         # ~300 lines — bottom status bar (already partially extracted)
    FlowKeyboardShortcuts.ts  # ~200 lines — keyboard event handlers
    FlowChainControls.tsx     # ~300 lines — chain execution UI, activity log
    FlowCollaboration.ts      # ~200 lines — WebSocket sync, presence
```

### Migration Approach

1. **Extract pure functions first** — anything that doesn't use React state
2. **Extract sub-components** — overlay manager, menu bar, etc.
3. **Extract custom hooks** — state management into `useFlowWorkspaceState()`
4. **Thin the orchestrator** — FlowWorkspace.tsx becomes a composition root
5. **Verify at each step** — `npm run check` + manual smoke test

### Risk Mitigation
- Each extraction is a single PR with before/after screenshots
- No behavior changes during decomposition — pure refactor
- Keep all exports stable so nothing else breaks

---

## 1.3 Error Monitoring

**Status:** Partial — error log button exists (v0.16.2) but it's client-side only

### Current State
- `errorLog.ts` captures API/network errors in memory
- Error log button in status bar shows collected errors
- No server-side structured logging
- No error aggregation or alerting
- No correlation between client and server errors

### Plan

#### Client-Side
```typescript
// Enhanced error boundary with reporting
class AppErrorBoundary extends React.Component {
  componentDidCatch(error, errorInfo) {
    // 1. Log to local error store (existing)
    addToErrorLog(error);

    // 2. Report to server (new)
    fetch("/api/errors/report", {
      method: "POST",
      body: JSON.stringify({
        message: error.message,
        stack: error.stack,
        componentStack: errorInfo.componentStack,
        url: window.location.href,
        timestamp: new Date().toISOString(),
        version: APP_VERSION,
      }),
    }).catch(() => {}); // Don't fail on reporting failure
  }
}
```

#### Server-Side
```typescript
// Structured logging middleware
function requestLogger(req, res, next) {
  const start = Date.now();
  res.on("finish", () => {
    const duration = Date.now() - start;
    const log = {
      method: req.method,
      path: req.path,
      status: res.statusCode,
      duration,
      userId: req.auth?.userId,
      timestamp: new Date().toISOString(),
      ...(res.statusCode >= 400 && { error: res.errorMessage }),
    };

    if (res.statusCode >= 500) {
      console.error(JSON.stringify(log));
    } else if (res.statusCode >= 400) {
      console.warn(JSON.stringify(log));
    } else {
      console.log(JSON.stringify(log));
    }
  });
  next();
}
```

#### Error Aggregation (Phase 2)
- Store errors in DB table for admin dashboard
- Group by error message + stack trace
- Show frequency, affected users, first/last seen
- Admin endpoint: `GET /api/admin/errors`

---

## 1.4 Code Health

### TypeScript Strictness
- Enable `strict: true` in tsconfig (currently not fully strict)
- Fix all `any` types in critical paths
- Add return types to all API handlers

### Dead Code Removal
- Audit for unused exports, unreachable code
- Remove commented-out code blocks
- Clean up deprecated feature flags

### Dependency Audit
- Remove unused npm packages
- Update packages with known vulnerabilities
- Pin major versions to prevent breaking changes

---

## 1.5 Task Checklist

| # | Task | Priority | Status | Dependencies |
|---|------|----------|--------|-------------|
| 1.1.1 | Install Vitest + testing-library + supertest | P0 | TODO | — |
| 1.1.2 | Create test setup (helpers, mocks, test DB) | P0 | TODO | 1.1.1 |
| 1.1.3 | Write encryption round-trip tests | P0 | TODO | 1.1.2 |
| 1.1.4 | Write API endpoint tests (documents) | P0 | TODO | 1.1.2 |
| 1.1.5 | Write API endpoint tests (canvas) | P0 | TODO | 1.1.2 |
| 1.1.6 | Write chain execution tests | P0 | TODO | 1.1.2 |
| 1.1.7 | Write LLM routing tests | P0 | TODO | 1.1.2 |
| 1.1.8 | Write edge role tests | P0 | TODO | 1.1.2 |
| 1.1.9 | Write component render tests (17 node types) | P1 | TODO | 1.1.2 |
| 1.1.10 | Write persona system tests | P1 | TODO | 1.1.2 |
| 1.2.1 | Extract FlowDockConfig | P0 | TODO | — |
| 1.2.2 | Extract FlowOverlayManager | P0 | TODO | 1.2.1 |
| 1.2.3 | Extract FlowToolHandlers | P0 | TODO | 1.2.1 |
| 1.2.4 | Extract FlowWorkspaceState hook | P0 | TODO | 1.2.1–1.2.3 |
| 1.2.5 | Extract FlowCanvasActions | P1 | TODO | 1.2.4 |
| 1.2.6 | Extract FlowMenuBar | P1 | TODO | 1.2.4 |
| 1.2.7 | Extract FlowKeyboardShortcuts | P1 | TODO | 1.2.4 |
| 1.3.1 | Add structured request logging middleware | P1 | TODO | — |
| 1.3.2 | Add server-side error reporting endpoint | P1 | TODO | 1.3.1 |
| 1.3.3 | Add error aggregation DB table + admin view | P2 | TODO | 1.3.2 |
| 1.4.1 | Enable strict TypeScript | P1 | TODO | 1.1.x |
| 1.4.2 | Dependency audit and cleanup | P1 | TODO | — |
| 1.4.3 | Dead code removal pass | P2 | TODO | — |
