# Track 9: AI & LLM Enhancements

**Parent:** [the_v1_plan.md](./the_v1_plan.md)
**Priority:** Medium-High
**Milestone:** M4 (v0.30–v0.39)

---

## 9.1 Prompt Engineering Pass

### Current State
- Each app has system guidance in `server/context-builder.ts`
- Personas have challenge + advice prompts in `shared/personas.ts`
- LLM presets (Summarize, Clean, Expand, Custom) in `llm-presets.ts`
- Research chat has its own system prompt in the streaming endpoint

### Optimization Goals

1. **Reduce prompt size** — Many system prompts are verbose. Trim without losing quality.
2. **Improve instruction following** — Some prompts produce inconsistent output formats.
3. **Template variables** — Use structured placeholders instead of string concatenation.
4. **A/B testing framework** — Compare prompt variants for quality.

### Prompt Audit Checklist

| Endpoint | Current Prompt Size (est.) | Target | Issues |
|----------|---------------------------|--------|--------|
| `/api/generate-challenges` | ~2000 chars | ~1500 | Sometimes generates generic challenges |
| `/api/generate-advice` | ~1800 chars | ~1200 | Advice sometimes overlaps with challenge |
| `/api/write` | ~3000 chars | ~2000 | Instruction classification sometimes wrong |
| `/api/chat/stream` | ~1500 chars | ~1200 | Could be more focused |
| `/api/interview/question` | ~2500 chars | ~1800 | Question quality varies by stance |
| `/api/discussion/ask` | ~2000 chars | ~1500 | Multi-persona responses sometimes too similar |

### Prompt Template System

```typescript
// server/prompt-templates.ts

interface PromptTemplate {
  id: string;
  version: number;
  template: string;           // With {{variable}} placeholders
  variables: string[];        // Required variables
  maxOutputTokens: number;    // Expected output size
  temperature: number;        // Recommended temperature
}

// Example
const CHALLENGE_PROMPT: PromptTemplate = {
  id: "generate-challenge",
  version: 3,
  template: `You are {{personaRole}}.

Analyze this document and identify {{challengeCount}} specific gaps,
weaknesses, or missed opportunities from your expert perspective.

DOCUMENT:
{{documentContent}}

OBJECTIVE:
{{objective}}

CONTEXT:
{{contextDocs}}

Rules:
- Each challenge must be specific and actionable
- Reference exact sections of the document
- Don't offer solutions — only identify problems
- Output as JSON array of {title, description, section}`,
  variables: ["personaRole", "challengeCount", "documentContent", "objective", "contextDocs"],
  maxOutputTokens: 1000,
  temperature: 0.7,
};
```

---

## 9.2 Model Routing (Cost Optimization)

**Current state:** Single model for all calls (default: Gemini 2.0 Flash). All tasks use the same model regardless of complexity.

### Smart Routing Strategy

```typescript
// server/model-router.ts

type TaskComplexity = "simple" | "moderate" | "complex";

interface ModelRoute {
  model: string;
  maxTokens: number;
  temperature: number;
  costPerMToken: number;
}

const MODEL_ROUTES: Record<TaskComplexity, ModelRoute> = {
  simple: {
    model: "gemini-2.0-flash",    // Fast, cheap
    maxTokens: 500,
    temperature: 0.3,
    costPerMToken: 0.075,
  },
  moderate: {
    model: "gemini-2.0-flash",    // Good balance
    maxTokens: 2000,
    temperature: 0.7,
    costPerMToken: 0.075,
  },
  complex: {
    model: "gemini-2.5-pro",      // Best quality
    maxTokens: 8000,
    temperature: 0.8,
    costPerMToken: 1.25,
  },
};

// Route tasks to appropriate models
function routeTask(taskType: string, inputSize: number): ModelRoute {
  const complexity = classifyComplexity(taskType, inputSize);
  return MODEL_ROUTES[complexity];
}

function classifyComplexity(taskType: string, inputSize: number): TaskComplexity {
  // Simple: summarize-intent, clean-up, short completions
  if (["summarize-intent", "clean"].includes(taskType)) return "simple";

  // Complex: full document rewrites, multi-persona discussion, research synthesis
  if (inputSize > 10000 || ["write-full", "discussion", "research-synthesis"].includes(taskType)) {
    return "complex";
  }

  // Everything else
  return "moderate";
}
```

### User Model Override

Allow Pro/Team users to select their preferred model:
```typescript
// User preference: default model per task type
// Settings → AI Preferences
// "Use best quality model (slower, costs more credits)"
// "Use fast model (quicker, costs fewer credits)"
// "Auto (let the system decide)"
```

---

## 9.3 Context Window Management

### Problem
Large documents + pinned context + persona prompts can exceed model context windows. Currently no protection against this.

### Solution

```typescript
// server/context-manager.ts

const MODEL_CONTEXT_LIMITS: Record<string, number> = {
  "gemini-2.0-flash": 1_000_000,  // 1M tokens
  "gemini-2.5-pro": 1_000_000,
  "gpt-4o": 128_000,
  "claude-sonnet-4-6": 200_000,
};

interface ContextBudget {
  systemPrompt: number;      // Reserved for system instructions
  userContent: number;       // The document being worked on
  contextDocs: number;       // Pinned/connected context documents
  conversationHistory: number; // Chat/interview history
  outputBuffer: number;      // Reserved for response
}

function allocateContextBudget(model: string, taskType: string): ContextBudget {
  const total = MODEL_CONTEXT_LIMITS[model] || 128_000;
  const outputBuffer = Math.min(total * 0.1, 8000);
  const systemPrompt = 2000;
  const remaining = total - outputBuffer - systemPrompt;

  // Allocate remaining based on task type
  switch (taskType) {
    case "research-chat":
      return {
        systemPrompt,
        userContent: 0,
        contextDocs: remaining * 0.3,
        conversationHistory: remaining * 0.7,
        outputBuffer,
      };
    case "write":
      return {
        systemPrompt,
        userContent: remaining * 0.5,
        contextDocs: remaining * 0.3,
        conversationHistory: remaining * 0.2,
        outputBuffer,
      };
    default:
      return {
        systemPrompt,
        userContent: remaining * 0.4,
        contextDocs: remaining * 0.4,
        conversationHistory: remaining * 0.2,
        outputBuffer,
      };
  }
}

// Truncate content to fit budget, preserving the most relevant parts
function fitToBudget(content: string, tokenBudget: number): string {
  const tokens = estimateTokens(content);
  if (tokens <= tokenBudget) return content;

  // Strategy: keep beginning and end, truncate middle
  const charBudget = tokenBudget * 4; // ~4 chars/token
  const keepStart = Math.floor(charBudget * 0.6);
  const keepEnd = Math.floor(charBudget * 0.4);

  return content.slice(0, keepStart) +
    "\n\n[... content truncated for context window ...]\n\n" +
    content.slice(-keepEnd);
}
```

---

## 9.4 LLM Response Quality

### 9.4.1 Output Validation

```typescript
// Validate LLM responses match expected format
function validateLlmOutput(output: string, expectedFormat: "json" | "markdown" | "text"): {
  valid: boolean;
  parsed?: any;
  error?: string;
} {
  switch (expectedFormat) {
    case "json":
      try {
        const parsed = JSON.parse(output);
        return { valid: true, parsed };
      } catch {
        // Try to extract JSON from markdown code blocks
        const jsonMatch = output.match(/```json?\s*([\s\S]*?)```/);
        if (jsonMatch) {
          try {
            return { valid: true, parsed: JSON.parse(jsonMatch[1]) };
          } catch {}
        }
        return { valid: false, error: "Invalid JSON response" };
      }
    case "markdown":
      return { valid: output.length > 0, parsed: output };
    default:
      return { valid: true, parsed: output };
  }
}
```

### 9.4.2 Retry with Fallback

```typescript
// If primary model fails, retry with a different model
async function generateWithFallback(prompt, options) {
  const models = ["gemini-2.0-flash", "gemini-2.5-pro"];

  for (const model of models) {
    try {
      const result = await llm.generate(prompt, { ...options, model });
      const validated = validateLlmOutput(result, options.expectedFormat);
      if (validated.valid) return validated.parsed;
    } catch (error) {
      console.warn(`Model ${model} failed, trying next...`);
    }
  }

  throw new Error("All models failed to generate valid output");
}
```

### 9.4.3 Response Caching

```typescript
// Cache identical prompts to avoid redundant LLM calls
// Useful for: persona definitions, system prompts, repeated patterns

const responseCache = new LRUCache<string, string>({
  max: 500,
  ttl: 1000 * 60 * 30, // 30 minutes
});

function getCacheKey(prompt: string, model: string): string {
  return createHash("sha256").update(`${model}:${prompt}`).digest("hex");
}
```

---

## 9.5 AI Features Wishlist

### 9.5.1 Smart Suggestions

While user is typing in a document, offer inline suggestions:
- "You mentioned X but haven't addressed Y — want to expand on that?"
- "This section could benefit from a concrete example"
- "Consider adding a transition between these paragraphs"

### 9.5.2 Auto-Tagging

When documents are saved, auto-generate tags based on content:
- Topic detection (technology, business, marketing, etc.)
- Key entity extraction (people, companies, technologies mentioned)
- Sentiment/tone classification

### 9.5.3 Cross-Document Intelligence

When multiple documents are in the Context Store:
- Detect contradictions between documents
- Suggest connections/relationships
- Generate summary of all documents
- "What's missing across all your documents?"

### 9.5.4 Chain Optimization

AI-assisted chain building:
- "This chain would benefit from a coherence gate after the LLM node"
- "These two research nodes could be parallelized"
- Auto-suggest edge roles based on node types

---

## 9.6 Task Checklist

| # | Task | Priority | Status | Dependencies |
|---|------|----------|--------|-------------|
| 9.1.1 | Prompt audit (all endpoints) | P1 | TODO | — |
| 9.1.2 | Prompt template system | P1 | TODO | — |
| 9.1.3 | Reduce prompt sizes by 30%+ | P1 | TODO | 9.1.1 |
| 9.2.1 | Model routing by task complexity | P1 | TODO | — |
| 9.2.2 | User model preference setting | P2 | TODO | 9.2.1, Track 6 |
| 9.3.1 | Context budget allocation | P0 | TODO | — |
| 9.3.2 | Content truncation with smart selection | P0 | TODO | 9.3.1 |
| 9.4.1 | LLM output validation | P1 | TODO | — |
| 9.4.2 | Retry with model fallback | P1 | TODO | — |
| 9.4.3 | Response caching | P2 | TODO | — |
| 9.5.1 | Smart inline suggestions | P2 | TODO | — |
| 9.5.2 | Auto-tagging | P2 | TODO | Track 5 (tagging system) |
| 9.5.3 | Cross-document intelligence | P2 | TODO | — |
| 9.5.4 | Chain optimization suggestions | P2 | TODO | — |
