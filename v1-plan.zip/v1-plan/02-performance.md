# Track 2: Performance

**Parent:** [the_v1_plan.md](./the_v1_plan.md)
**Priority:** High
**Milestone:** M1 (v0.17–v0.19)

---

## 2.1 Canvas Rendering Performance

**Current state:** Canvas works well for small-to-medium flows (10-30 nodes). Performance degrades noticeably with 50+ nodes due to full React re-renders on every viewport change.

### Problems
1. **Every node re-renders on pan/zoom** — viewport transform changes trigger re-render of all FlowNodeRenderer components
2. **SVG edge layer redraws entirely** — FlowEdgeLayer recalculates all curves on any node move
3. **No virtualization** — off-screen nodes are fully rendered and updated
4. **Large node content** — expanded research conversations, document content stored in node state causes heavy serialization

### Solutions

#### 2.1.1 Viewport Transform via CSS (not React state)

```typescript
// Current: React state drives viewport → re-renders everything
const [viewport, setViewport] = useState({ x: 0, y: 0, zoom: 1 });
// Every setViewport call re-renders all children

// Target: CSS transform on container, bypass React
const viewportRef = useRef({ x: 0, y: 0, zoom: 1 });
const containerRef = useRef<HTMLDivElement>(null);

function updateViewport(x, y, zoom) {
  viewportRef.current = { x, y, zoom };
  if (containerRef.current) {
    containerRef.current.style.transform =
      `translate(${x}px, ${y}px) scale(${zoom})`;
  }
  // No setState — no React re-render
}
```

#### 2.1.2 Node Virtualization

Only render nodes whose bounding box intersects the visible viewport:

```typescript
function useVisibleNodes(nodes, viewport, canvasSize) {
  return useMemo(() => {
    const visibleRect = {
      left: -viewport.x / viewport.zoom,
      top: -viewport.y / viewport.zoom,
      right: (-viewport.x + canvasSize.width) / viewport.zoom,
      bottom: (-viewport.y + canvasSize.height) / viewport.zoom,
    };

    // Add margin for nodes partially visible
    const margin = 200;
    return nodes.filter(node =>
      node.x + node.width > visibleRect.left - margin &&
      node.x < visibleRect.right + margin &&
      node.y + node.height > visibleRect.top - margin &&
      node.y < visibleRect.bottom + margin
    );
  }, [nodes, viewport.x, viewport.y, viewport.zoom, canvasSize]);
}
```

#### 2.1.3 Edge Rendering Optimization

```typescript
// Current: recalculate ALL edge paths on any change
// Target: only recalculate edges connected to moved nodes

function useOptimizedEdges(edges, nodes, movedNodeId) {
  const edgePaths = useRef(new Map<string, string>());

  useMemo(() => {
    for (const edge of edges) {
      // Only recalculate if source or target moved
      if (edge.sourceId === movedNodeId || edge.targetId === movedNodeId ||
          !edgePaths.current.has(edge.id)) {
        edgePaths.current.set(edge.id, calculateCurvedPath(edge, nodes));
      }
    }
  }, [edges, nodes, movedNodeId]);

  return edgePaths.current;
}
```

#### 2.1.4 React.memo Boundaries

```typescript
// Wrap expensive node renderers
const MemoizedFlowNode = React.memo(FlowNodeRenderer, (prev, next) => {
  // Only re-render if node data actually changed
  return prev.node.id === next.node.id &&
         prev.node.x === next.node.x &&
         prev.node.y === next.node.y &&
         prev.node.label === next.node.label &&
         prev.node.content === next.node.content &&
         prev.node.llmStatus === next.node.llmStatus &&
         prev.isSelected === next.isSelected;
});
```

### Performance Targets

| Metric | Current (est.) | Target |
|--------|---------------|--------|
| 50-node canvas FPS during pan | ~20 fps | 60 fps |
| 100-node canvas FPS during pan | ~8 fps | 30+ fps |
| Node drag latency | ~30ms | <16ms |
| Edge recalculation on drag | all edges | only connected edges |

---

## 2.2 Bundle Size & Load Performance

### Current State
- No code splitting beyond Vite's default
- All 17 node expanded views loaded upfront
- All 47 shadcn components in main bundle
- No lazy loading of routes

### Plan

#### 2.2.1 Route-Level Code Splitting

```typescript
// App.tsx — lazy load routes
const FlowWorkspace = React.lazy(() => import("./pages/FlowWorkspace"));
const ContextStore = React.lazy(() => import("./pages/ContextStore"));
const Admin = React.lazy(() => import("./pages/Admin"));
const Pricing = React.lazy(() => import("./pages/Pricing"));
const ProjectOverview = React.lazy(() => import("./pages/ProjectOverview"));
```

#### 2.2.2 Expanded View Lazy Loading

```typescript
// Load expanded views only when user double-clicks a node
const expandedViewLoaders: Record<FlowNodeType, () => Promise<ComponentType>> = {
  research: () => import("./expanded/ResearchExpandedView"),
  interview: () => import("./expanded/FlowInterviewOverlay"),
  painter: () => import("./expanded/PainterExpandedView"),
  // ... etc
};

function ExpandedOverlay({ nodeType, ...props }) {
  const Component = React.lazy(expandedViewLoaders[nodeType]);
  return (
    <Suspense fallback={<LoadingSkeleton />}>
      <Component {...props} />
    </Suspense>
  );
}
```

#### 2.2.3 Bundle Analysis

```bash
# Add to package.json scripts
"analyze": "vite build --mode analyze"

# Use rollup-plugin-visualizer to identify large chunks
# Target: main bundle < 500KB gzipped
# Target: total app < 1.5MB gzipped
```

---

## 2.3 API Performance

### 2.3.1 Database Query Optimization

```typescript
// Current: multiple sequential queries in many endpoints
// Target: batch queries, use JOINs, add indexes

// Example: loading a canvas with all related documents
// Current: 1 query for canvas + N queries for each pinned doc
// Target: single query with JOIN
const canvasWithDocs = await db
  .select()
  .from(documents)
  .leftJoin(pinnedDocs, eq(documents.id, pinnedDocs.canvasId))
  .where(eq(documents.id, canvasId));
```

#### Missing Indexes to Add
```sql
-- Document lookups by userId (most common query)
CREATE INDEX IF NOT EXISTS idx_documents_user_id ON documents(user_id);

-- Folder lookups by userId
CREATE INDEX IF NOT EXISTS idx_folders_user_id ON folders(user_id);

-- Message lookups by conversation
CREATE INDEX IF NOT EXISTS idx_messages_conversation_id ON messages(conversation_id);

-- LLM call logs by timestamp for admin dashboard
CREATE INDEX IF NOT EXISTS idx_llm_calls_created_at ON llm_calls(created_at);
```

### 2.3.2 Response Caching

```typescript
// Cache static/slow-changing data
// Personas: changes only on admin edit (cache 5 min)
// Models list: changes on server restart (cache 10 min)
// User preferences: changes on explicit save (cache per-request)

const cache = new Map<string, { data: any; expires: number }>();

function withCache(key: string, ttlMs: number, fn: () => Promise<any>) {
  const cached = cache.get(key);
  if (cached && cached.expires > Date.now()) return cached.data;

  const result = fn();
  cache.set(key, { data: result, expires: Date.now() + ttlMs });
  return result;
}
```

### 2.3.3 Streaming Response Optimization

```typescript
// Current: SSE streams buffer on server side
// Ensure proper chunked transfer encoding
// Set appropriate headers for SSE
res.setHeader("Cache-Control", "no-cache");
res.setHeader("Connection", "keep-alive");
res.setHeader("X-Accel-Buffering", "no"); // Disable nginx buffering
```

---

## 2.4 Auto-Save Performance

**Current state:** Auto-save triggers on every node/edge change with 2-second debounce. Encryption happens on every save.

### Optimizations

#### 2.4.1 Diff-Based Saves

```typescript
// Current: serialize + encrypt entire canvas on every save
// Target: only save if content actually changed

const lastSaveHash = useRef<string>("");

function shouldSave(nodes, edges) {
  const hash = quickHash(JSON.stringify({ nodes, edges }));
  if (hash === lastSaveHash.current) return false;
  lastSaveHash.current = hash;
  return true;
}
```

#### 2.4.2 Master Key Caching (DONE in v0.16.0)
Already implemented — master key caching eliminates per-encrypt PBKDF2 cost.

#### 2.4.3 Background Save Worker

```typescript
// Move serialization + encryption to a Web Worker
// so the main thread stays responsive during saves
const saveWorker = new Worker("save-worker.js");

function saveCanvas(nodes, edges) {
  saveWorker.postMessage({ type: "save", nodes, edges });
}

saveWorker.onmessage = (e) => {
  if (e.data.type === "encrypted") {
    // POST the already-encrypted payload
    fetch(`/api/documents/${id}`, {
      method: "PUT",
      body: e.data.payload,
    });
  }
};
```

---

## 2.5 Task Checklist

| # | Task | Priority | Status | Dependencies |
|---|------|----------|--------|-------------|
| 2.1.1 | CSS transform viewport (bypass React re-renders) | P0 | TODO | — |
| 2.1.2 | Node virtualization (off-screen culling) | P0 | TODO | 2.1.1 |
| 2.1.3 | Edge rendering optimization (incremental) | P1 | TODO | 2.1.1 |
| 2.1.4 | React.memo on node renderers | P1 | TODO | — |
| 2.2.1 | Route-level code splitting | P1 | TODO | — |
| 2.2.2 | Lazy-load expanded views | P1 | TODO | — |
| 2.2.3 | Bundle analysis + size targets | P1 | TODO | — |
| 2.3.1 | Add missing database indexes | P0 | TODO | — |
| 2.3.2 | Server-side response caching | P1 | TODO | — |
| 2.3.3 | SSE streaming optimization | P2 | TODO | — |
| 2.4.1 | Diff-based save (skip unchanged) | P1 | TODO | — |
| 2.4.3 | Web Worker for save encryption | P2 | TODO | — |
