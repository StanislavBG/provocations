# Track 8: Documentation & Help

**Parent:** [the_v1_plan.md](./the_v1_plan.md)
**Priority:** Medium
**Milestone:** M3 (v0.25–v0.29)

---

## 8.1 In-App Help System

**Current state:** Component wiki exists at `/components`. Tooltips on dock items (added v0.16.4). No contextual help or user-facing documentation.

### 8.1.1 Contextual Help (? Button)

Every major panel gets a `?` button that opens contextual help:

```typescript
// Reusable help trigger
function HelpButton({ topic }: { topic: HelpTopic }) {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" className="h-6 w-6">
          <HelpCircle className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent>
        <HelpContent topic={topic} />
      </DialogContent>
    </Dialog>
  );
}

// Help topics map to markdown content
type HelpTopic =
  | "canvas-basics"
  | "connecting-nodes"
  | "chain-execution"
  | "research-chat"
  | "interview-mode"
  | "context-store"
  | "edge-roles"
  | "personas"
  | "blueprints"
  | "keyboard-shortcuts";
```

### 8.1.2 Keyboard Shortcut Overlay

Press `?` or `Ctrl+/` to show all keyboard shortcuts:

```
Keyboard Shortcuts:
  Canvas Navigation:
    W/A/S/D       Pan canvas
    Scroll        Zoom in/out
    F             Fit all nodes in view
    Space+Drag    Pan (alternative)

  Node Operations:
    Delete/Backspace  Delete selected nodes
    Ctrl+D            Duplicate selected
    Ctrl+Z            Undo
    Ctrl+Shift+Z      Redo
    Ctrl+A            Select all
    Escape            Deselect / Close overlay

  Canvas:
    Ctrl+S            Save canvas
    Ctrl+N            New canvas
    Ctrl+O            Open canvas

  Panels:
    ?                 Show keyboard shortcuts
    Ctrl+/            Show keyboard shortcuts
```

### 8.1.3 Tooltip Enhancement

Beyond dock tooltips, add tooltips to:
- Node port dots ("Connect to another node")
- Edge role badges ("This edge carries context data")
- Status indicators ("Processing — click to view activity log")
- Menu items (brief description of each action)

---

## 8.2 User Guide

### 8.2.1 In-App Guide (Markdown Pages)

```
/help
  ├── Getting Started
  │     ├── What is Provocations?
  │     ├── Your First Canvas
  │     └── Core Concepts
  ├── The Canvas
  │     ├── Navigation (pan, zoom, WASD)
  │     ├── Adding Nodes
  │     ├── Connecting Nodes
  │     ├── Edge Roles
  │     └── Chain Execution
  ├── Node Types
  │     ├── Research
  │     ├── Interview
  │     ├── Text Mods (LLM)
  │     ├── Document
  │     ├── Context
  │     ├── YouTube
  │     ├── Painter
  │     ├── Audio
  │     ├── Social Post
  │     ├── Logic Nodes
  │     └── ...
  ├── Features
  │     ├── Personas & Provocations
  │     ├── Voice Input
  │     ├── Blueprints
  │     ├── Context Store
  │     └── Collaboration
  ├── Keyboard Shortcuts
  └── FAQ
```

### 8.2.2 Implementation

Help content as markdown files, rendered in-app:

```typescript
// client/src/lib/helpContent.ts
export const HELP_PAGES: Record<string, { title: string; content: string }> = {
  "getting-started": {
    title: "Getting Started",
    content: `
# Getting Started with Provocations

Provocations is an AI-augmented workspace where you build ideas into
polished documents through voice, text, and thought-provoking AI interactions.

## Your First Canvas

1. **Add a Research node** — Drag "Research" from the dock onto the canvas
2. **Ask a question** — Double-click the node and start a conversation
3. **Connect to a Document** — Add a Document node and connect them
4. **Run the chain** — Click Play on the Document node to process research into a document
    `,
  },
  // ... more pages
};
```

---

## 8.3 Changelog & Release Notes

**Current state:** Release notes exist in `version.ts` and are viewable in Settings. Good foundation.

### Enhancements

- Show "What's New" badge on version watermark when a new version is detected
- Auto-show release notes dialog on first visit after an update
- Categorize changes (New Features, Bug Fixes, Improvements)
- Link to relevant help pages from release notes

---

## 8.4 API Documentation

### For Future API Access (Team tier)

```
/api-docs (Swagger/OpenAPI)
  ├── Authentication (Clerk JWT)
  ├── Documents
  │     ├── POST /api/documents
  │     ├── GET /api/documents
  │     ├── GET /api/documents/:id
  │     ├── PUT /api/documents/:id
  │     └── DELETE /api/documents/:id
  ├── AI
  │     ├── POST /api/chat/stream
  │     ├── POST /api/write
  │     └── POST /api/generate-challenges
  └── Usage
        ├── GET /api/usage
        └── GET /api/billing/status
```

---

## 8.5 Task Checklist

| # | Task | Priority | Status | Dependencies |
|---|------|----------|--------|-------------|
| 8.1.1 | Contextual help (? buttons) | P1 | TODO | — |
| 8.1.2 | Keyboard shortcut overlay | P0 | TODO | — |
| 8.1.3 | Enhanced tooltips across app | P2 | TODO | — |
| 8.2.1 | Help content (markdown pages) | P1 | TODO | — |
| 8.2.2 | Help page routing + renderer | P1 | TODO | 8.2.1 |
| 8.3.1 | "What's New" badge + auto-show | P2 | TODO | — |
| 8.4.1 | OpenAPI spec for public endpoints | P2 | TODO | Track 6 (API access tier) |
