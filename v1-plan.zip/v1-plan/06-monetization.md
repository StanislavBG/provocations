# Track 6: Monetization & Business

**Parent:** [the_v1_plan.md](./the_v1_plan.md)
**Priority:** High
**Milestone:** M3 (v0.25–v0.29)
**Reference:** [docs/stripe-integration.md](../stripe-integration.md) (existing)

---

## 6.1 Plan Tiers

### Tier Structure

| Feature | Free | Pro ($19/mo) | Team ($39/user/mo) |
|---------|------|-------------|-------------------|
| Canvas saves | 3 | Unlimited | Unlimited |
| Nodes per canvas | 15 | Unlimited | Unlimited |
| LLM calls/day | 25 | 200 | 500 |
| TTS (ElevenLabs) | None | 50 min/mo | 200 min/mo |
| Image generation | 5/day | 50/day | 200/day |
| Context Store storage | 100MB | 5GB | 25GB |
| File upload size | 10MB | 50MB | 100MB |
| Blueprints | Built-in only | + Custom + Share | + Team library |
| Personas | Built-in only | + Custom (5) | + Custom (unlimited) |
| Collaboration | View only | 3 shared canvases | Unlimited + real-time |
| Team workspaces | No | No | Yes |
| Priority support | No | Email | Chat + email |
| API access | No | No | Yes (future) |

### Usage Metering Architecture

```typescript
// server/usage.ts

interface UsageLimits {
  llmCallsPerDay: number;
  ttsMinsPerMonth: number;
  imagesPerDay: number;
  storageMb: number;
  canvases: number;
  nodesPerCanvas: number;
}

const PLAN_LIMITS: Record<PlanTier, UsageLimits> = {
  free: {
    llmCallsPerDay: 25,
    ttsMinsPerMonth: 0,
    imagesPerDay: 5,
    storageMb: 100,
    canvases: 3,
    nodesPerCanvas: 15,
  },
  pro: {
    llmCallsPerDay: 200,
    ttsMinsPerMonth: 50,
    imagesPerDay: 50,
    storageMb: 5120,
    canvases: Infinity,
    nodesPerCanvas: Infinity,
  },
  team: {
    llmCallsPerDay: 500,
    ttsMinsPerMonth: 200,
    imagesPerDay: 200,
    storageMb: 25600,
    canvases: Infinity,
    nodesPerCanvas: Infinity,
  },
};

// Check usage before every metered action
async function checkUsage(userId: string, resource: keyof UsageLimits): Promise<boolean> {
  const plan = await getUserPlan(userId);
  const limits = PLAN_LIMITS[plan];
  const current = await getCurrentUsage(userId, resource);
  return current < limits[resource];
}

// Middleware for metered endpoints
function requireUsage(resource: keyof UsageLimits) {
  return async (req, res, next) => {
    const allowed = await checkUsage(req.auth.userId, resource);
    if (!allowed) {
      return res.status(429).json({
        error: "Usage limit reached",
        resource,
        upgrade: "/pricing",
      });
    }
    next();
  };
}
```

---

## 6.2 Stripe Integration

### 6.2.1 Setup

```typescript
// server/stripe.ts
import Stripe from "stripe";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

// Products created in Stripe Dashboard:
// prod_provocations_pro  → price_pro_monthly ($19/mo)
// prod_provocations_team → price_team_monthly ($39/user/mo)
```

### 6.2.2 Checkout Flow

```
User clicks "Upgrade" →
  ├── Client: POST /api/billing/checkout-session
  │     Body: { planId: "pro" | "team", billingPeriod: "monthly" | "annual" }
  ├── Server: stripe.checkout.sessions.create({
  │     customer: stripeCustomerId (or create new),
  │     line_items: [{ price: priceId, quantity: 1 }],
  │     mode: "subscription",
  │     success_url: "/settings/billing?session_id={CHECKOUT_SESSION_ID}",
  │     cancel_url: "/pricing",
  │   })
  ├── Server returns: { url: session.url }
  └── Client: window.location.href = session.url
```

### 6.2.3 Webhook Handling

```typescript
// server/routes.ts
app.post("/api/stripe/webhook", express.raw({ type: "application/json" }), async (req, res) => {
  const sig = req.headers["stripe-signature"];
  const event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);

  switch (event.type) {
    case "checkout.session.completed":
      // Activate subscription
      await activateSubscription(event.data.object);
      break;
    case "invoice.paid":
      // Renew subscription
      await renewSubscription(event.data.object);
      break;
    case "invoice.payment_failed":
      // Grace period — don't downgrade immediately
      await flagPaymentFailed(event.data.object);
      break;
    case "customer.subscription.deleted":
      // Downgrade to free
      await downgradeToFree(event.data.object);
      break;
  }

  res.json({ received: true });
});
```

### 6.2.4 Database Schema

```typescript
// shared/models/billing.ts
export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),  // Clerk userId
  stripeCustomerId: text("stripe_customer_id").notNull(),
  stripeSubscriptionId: text("stripe_subscription_id"),
  planTier: text("plan_tier").notNull().default("free"),  // free | pro | team
  status: text("status").notNull().default("active"),     // active | past_due | cancelled
  currentPeriodStart: timestamp("current_period_start"),
  currentPeriodEnd: timestamp("current_period_end"),
  cancelAtPeriodEnd: boolean("cancel_at_period_end").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const usageRecords = pgTable("usage_records", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  resource: text("resource").notNull(),  // llm_call | tts_minute | image_gen | storage_mb
  count: integer("count").notNull().default(1),
  date: date("date").notNull(),          // Daily bucketing
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => ({
  userDateIdx: index("idx_usage_user_date").on(table.userId, table.date),
}));
```

---

## 6.3 Billing UI

### 6.3.1 Pricing Page

Already exists at `/pricing`. Needs:
- Dynamic pricing based on actual Stripe prices
- Annual discount toggle (save 20%)
- Feature comparison matrix
- "Current plan" indicator for logged-in users
- FAQ section

### 6.3.2 Settings → Billing

```
/settings/billing
  ├── Current Plan card (tier, price, renewal date)
  ├── Usage Dashboard
  │     ├── LLM calls: 45/200 today
  │     ├── TTS: 12/50 minutes this month
  │     ├── Images: 8/50 today
  │     └── Storage: 1.2/5 GB
  ├── Payment Method (Stripe portal link)
  ├── Billing History (invoice list)
  ├── [Change Plan] button
  └── [Cancel Subscription] button
```

### 6.3.3 Usage Limit UI

When a user approaches or hits a limit:

```typescript
// 80% warning (toast)
"You've used 160 of 200 AI calls today. Upgrade for more."

// 100% block (modal)
"You've reached today's AI call limit (200/200)."
"[Upgrade to Team] [Wait until tomorrow]"

// Node creation limit
"Free plan allows 15 nodes per canvas. Upgrade for unlimited."
```

---

## 6.4 Revenue Analytics (Admin)

### Dashboard additions for admin:

```
Admin → Revenue
  ├── MRR (Monthly Recurring Revenue)
  ├── Active subscriptions by tier
  ├── Churn rate (monthly)
  ├── Trial → Paid conversion rate
  ├── Average Revenue Per User (ARPU)
  ├── LTV estimate
  ├── Usage by feature (what do paying users use most?)
  └── Cost analysis (LLM API spend vs. revenue)
```

---

## 6.5 Task Checklist

| # | Task | Priority | Status | Dependencies |
|---|------|----------|--------|-------------|
| 6.1.1 | Define plan tier limits (finalize numbers) | P0 | TODO | — |
| 6.1.2 | Build usage metering system | P0 | TODO | — |
| 6.1.3 | Add usage check middleware to metered endpoints | P0 | TODO | 6.1.2 |
| 6.2.1 | Stripe SDK setup + products/prices creation | P0 | TODO | — |
| 6.2.2 | Checkout session endpoint | P0 | TODO | 6.2.1 |
| 6.2.3 | Webhook handler (all events) | P0 | TODO | 6.2.1 |
| 6.2.4 | Subscriptions + usage DB tables | P0 | TODO | — |
| 6.3.1 | Pricing page with Stripe integration | P0 | TODO | 6.2.x |
| 6.3.2 | Billing settings page | P1 | TODO | 6.2.x |
| 6.3.3 | Usage limit UI (warnings + blocks) | P0 | TODO | 6.1.x |
| 6.4.1 | Revenue analytics admin dashboard | P2 | TODO | 6.2.x |
