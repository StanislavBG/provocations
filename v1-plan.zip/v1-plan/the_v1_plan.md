# Provocations v1.0 — The Plan

**Current version:** 0.16.12
**Target:** 1.0.0
**Status:** Planning
**Last updated:** 2026-03-07

---

## Vision

Provocations v1.0 is the release where we go from "impressive prototype with a ton of features" to "polished, reliable, production-grade product that people pay for and depend on."

The features are largely in place. What v1.0 needs is:
- **Stability** — things that work should work *every time*
- **Polish** — rough edges smoothed, inconsistencies resolved
- **Performance** — fast load, fast save, fast AI responses
- **Security** — production-grade auth, encryption, and data handling
- **Onboarding** — a new user can understand and use the product in minutes
- **Monetization** — Stripe integration, usage limits, plan tiers
- **Testing** — confidence that changes don't break things

---

## Current State Assessment

### What We Have (strengths)
- 17 node types on an infinite flow canvas with drag-drop, connections, and chain execution
- 14 AI personas with challenge/advice loop
- Streaming research chat, interview with voice + brainstorm mode
- ElevenLabs TTS integration with multi-context WebSocket
- Zero-knowledge AES-256-GCM encryption at rest
- Canvas save/load/share with auto-save and beacon flush
- Blueprints system (built-in + user-created + shared)
- Context Store with folder hierarchy, upload, and document management
- Multi-provider LLM support (Gemini, OpenAI, Anthropic)
- LLM call transparency (hover preview with token/cost estimates)
- Component wiki and project overview page
- 15 app templates across write/build/analyze/capture categories
- Edge roles (objective, context, output-format, system-instruction)
- Logic nodes (filter, gate, router, merge, coherence-gate)
- Activity logs with grouped view
- User-to-user messaging and connections
- Approval node for human-in-the-loop workflows
- Notification system
- Multi-select, undo/redo, WASD navigation, minimap, canvas themes

### What's Missing or Rough (gaps)
- No test suite (zero automated tests beyond the crypto/canvas compat tests)
- No CI/CD pipeline
- Performance issues with large canvases (FlowWorkspace.tsx is 7800+ lines)
- No structured error monitoring / logging in production
- Stripe integration planned but not built
- Mobile experience is minimal
- Onboarding / first-run experience is underdeveloped
- Accessibility (a11y) hasn't been audited
- No rate limiting or abuse prevention on API endpoints
- No offline/PWA support
- Documentation is internal (CLAUDE.md) — no user-facing docs/help

---

## Product Owner Guide

Before diving into tracks, read the **Product Owner Guide** — it's the coherence authority for all v1.0 work. Every agent team should check in with this document periodically to verify alignment, quality, and integration.

- [00-product-owner-guide.md](./00-product-owner-guide.md) — Product identity, values, quality bar, sprint review protocol, decision frameworks, anti-patterns, and the v1.0 readiness checklist

Use it as a **ride-along** during development: before starting work, during design decisions, and after completing tasks. It answers "are we building the right thing the right way?"

---

## Plan Structure

This plan is organized into **tracks** — parallel workstreams that can largely be developed independently. Each track has its own detailed document linked below.

### Track 1: Stability & Quality
The foundation. Testing, error handling, monitoring, and code health.

- [01-stability.md](./01-stability.md) — Testing framework, CI/CD, error monitoring, code splitting

### Track 2: Performance
Making everything fast. Rendering, network, bundle size, database.

- [02-performance.md](./02-performance.md) — Canvas rendering, bundle optimization, API performance, caching

### Track 3: Security & Compliance
Production-grade security posture.

- [03-security.md](./03-security.md) — Auth hardening, rate limiting, CSP, encryption audit, OWASP review

### Track 4: User Experience & Polish
The feel of a finished product.

- [04-ux-polish.md](./04-ux-polish.md) — Onboarding, accessibility, responsive design, UX consistency, keyboard shortcuts

### Track 5: Core Feature Completion
Finishing what we started and filling critical gaps.

- [05-features.md](./05-features.md) — Feature audit, incomplete flows, missing edge cases, feature parity across node types

### Track 6: Monetization & Business
Stripe, plans, usage tracking, billing.

- [06-monetization.md](./06-monetization.md) — Stripe integration, plan tiers, usage metering, billing UI

### Track 7: Infrastructure & DevOps
Build pipeline, deployment, environments, observability.

- [07-infrastructure.md](./07-infrastructure.md) — CI/CD, staging environment, structured logging, health checks, backups

### Track 8: Documentation & Help
User-facing documentation, in-app help, API docs.

- [08-documentation.md](./08-documentation.md) — Help system, tooltips, tutorials, API reference, changelog

### Track 9: AI & LLM Enhancements
Smarter AI, better prompts, cost optimization, model management.

- [09-ai-enhancements.md](./09-ai-enhancements.md) — Prompt engineering, model routing, cost controls, context window management

### Track 10: Collaboration & Social
Real-time collaboration, sharing, team features.

- [10-collaboration.md](./10-collaboration.md) — Real-time co-editing, presence, permissions, team workspaces, sharing

---

## Milestone Plan

### M1: Foundation (v0.17–v0.19)
**Focus:** Stability, testing, performance — the unglamorous essentials.
- Testing framework setup (Vitest) + critical path tests
- FlowWorkspace.tsx decomposition (break up the 7800-line monolith)
- CI pipeline (lint + typecheck + test on PR)
- Rate limiting on API endpoints
- Error monitoring setup
- Bundle size audit and code splitting

### M2: Security & Polish (v0.20–v0.24)
**Focus:** Security audit, UX polish, accessibility.
- OWASP Top 10 review and remediation
- CSP headers and security hardening
- Onboarding flow for new users
- Accessibility audit (WCAG 2.1 AA)
- Mobile responsiveness pass
- Keyboard navigation completeness

### M3: Business Ready (v0.25–v0.29)
**Focus:** Monetization, documentation, production readiness.
- Stripe integration with plan tiers
- Usage metering and limits
- User-facing help system
- Structured production logging
- Database backup strategy
- Staging environment

### M4: AI & Collaboration (v0.30–v0.39)
**Focus:** Smarter AI, real-time collaboration, team features.
- Prompt optimization pass across all endpoints
- Model routing (cheap models for simple tasks)
- Real-time canvas collaboration (WebSocket)
- Team workspaces and permissions
- Sharing improvements

### M5: Release Candidate (v0.40–v0.99)
**Focus:** Integration testing, beta feedback, final polish.
- End-to-end test suite
- Beta user program
- Performance benchmarks and targets
- Final UX review
- v1.0 release checklist

---

## Principles

1. **Don't break what works.** Every change must have test coverage. Regressions are unacceptable at this stage.
2. **Ship incrementally.** Each milestone should produce a better product, not just progress toward a future one.
3. **Parallel when possible.** Tracks are designed for independent work. Use agents in parallel across tracks.
4. **User-visible value first.** Within each track, prioritize changes users will notice over internal refactors.
5. **Measure before optimizing.** Don't guess at performance problems — profile, measure, then fix.
6. **Security is non-negotiable.** No shortcuts on auth, encryption, or data handling.

---

## How to Use This Plan

1. **Read the track docs** for detailed specs, pseudocode, and design decisions
2. **Pick a track + task** to work on — check dependencies in the milestone plan
3. **Claim work** by marking items `[IN PROGRESS]` in the relevant doc
4. **Update status** as you complete items — `[DONE]`, `[BLOCKED]`, `[DEFERRED]`
5. **Add detail** as you discover complexity — these docs are living documents

---

## Index of All Plan Documents

| # | Document | Track | Status |
|---|----------|-------|--------|
| 0 | [the_v1_plan.md](./the_v1_plan.md) | Parent | Active |
| PO | [00-product-owner-guide.md](./00-product-owner-guide.md) | Product Owner | Active |
| 1 | [01-stability.md](./01-stability.md) | Stability & Quality | Draft |
| 2 | [02-performance.md](./02-performance.md) | Performance | Draft |
| 3 | [03-security.md](./03-security.md) | Security & Compliance | Draft |
| 4 | [04-ux-polish.md](./04-ux-polish.md) | UX & Polish | Draft |
| 5 | [05-features.md](./05-features.md) | Feature Completion | Draft |
| 6 | [06-monetization.md](./06-monetization.md) | Monetization | Draft |
| 7 | [07-infrastructure.md](./07-infrastructure.md) | Infrastructure | Draft |
| 8 | [08-documentation.md](./08-documentation.md) | Documentation | Draft |
| 9 | [09-ai-enhancements.md](./09-ai-enhancements.md) | AI & LLM | Draft |
| 10 | [10-collaboration.md](./10-collaboration.md) | Collaboration | Draft |
